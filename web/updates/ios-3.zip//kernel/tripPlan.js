var detailTable = new Object();
detailTable['R'] = 'Reservation';
detailTable['L'] = 'Rental';
detailTable['T'] = 'Trip';
detailTable['D'] = 'Directions';
detailTable['E'] = 'Event';

var GETParams = document.location.href.substr(document.location.href.indexOf("?")).replace(/\#/,"");

var Calendars = null;

function move(srcPlanId, kind, id, hidden){
	var moveTo = document.getElementById('moveTo');
	document.getElementById('activeItemKind').value = kind;
	document.getElementById('activeItemId').value = id;
	while(moveTo.options.length > 1)
		moveTo.remove(moveTo.options.length-1);
	var plans = $('#travelPlansInfo div.head');
	var dates = $('travelPlansInfo div.dates');
	var srcPlan = document.getElementById('head'+srcPlanId);
	plans.each(function(n, plan){
		plan = $(plan);
		var targetId = plan.attr('travelPlanId');
		if(plan.html() != "Unfiled items" && targetId != srcPlanId && plan.data('hidden') != '1'){
			var option = document.createElement('OPTION');
			moveTo.options.add( option, moveTo.options.length );
			var dates = document.getElementById('dates'+targetId);
			option.innerHTML = plan.html();
			if(dates)
				option.innerHTML = option.innerHTML + ', ' + dates.innerHTML;
			option.value = targetId;
		}
	});
	var option = document.createElement('option');
	moveTo.options.add( option, moveTo.options.length );
	option.innerHTML = "Create new plan..";
	option.value = "new";
	document.getElementById('planName').style.display = 'none';
	moveTo.style.display = '';
	moveTo.value = '';
	document.getElementById('planName').value = '';
	var popup = document.getElementById('movePlanPopup');
	document.getElementById('movePlanHeader').innerHTML = detailTable[kind];
	document.getElementById('movePlanQuestion').innerHTML = 'Where would you like to move this '+document.getElementById('movePlanHeader').innerHTML+"?";
	showPopupWindow(popup, true);
}

function deleteIt(kind, id, hidden){
	document.getElementById('activeItemKind').value = kind;
	document.getElementById('activeItemId').value = id;
	document.getElementById('deleteButtons').style.display = '';
	document.getElementById('deleteProgress').style.display = 'none';
	showPopupWindow(document.getElementById('deletePopup'));
}

function checkIt(kind, id){
	document.getElementById('activeItemKind').value = kind;
	document.getElementById('activeItemId').value = id;
	document.getElementById('checkButtons').style.display = '';
	document.getElementById('checkProgress').style.display = 'none';
	document.getElementById('checkHeader').innerHTML = 'Checking..';
	document.getElementById('checkYesButton').style.display = 'none';
	$('checkCancelButton input').attr('value', 'Cancel');
	document.getElementById('checkQuestion').innerHTML = '<img src="/lib/images/progressCircle.gif" style="border: none; width: 16px; height: 16px;"/> Please wait while we are updating this reservation..';
	document.getElementById('checkPopup').style.height = '165px';
	showPopupWindow(document.getElementById('checkPopup'), true);
	$.ajax(
		{
			url: "/account/checkIt.php?Kind="+document.getElementById('activeItemKind').value+"&ID="+document.getElementById('activeItemId').value,
			success: function(response){
				if(response != 'OK'){
					if(response.match(/^\d+$/))
						document.location.href = '/trips/accountChecked.php?ID='+response+'&Source=SegmentCheck&BackTo='+url_encode(document.location.href);
					else
						showMessagePopup('error', 'Check failed', response);
					return false;
				}
				document.location.href = document.location.href;
			},
			error: ajaxError
		}
	);
}

function editSegment(){
	activePopup.style.display = 'none';
	switch(document.getElementById('activeItemKind').value){
		case 'T':
			document.location.href = '/trips/editTrip.php?ID='+document.getElementById('activeItemId').value;
			break;
		case 'R':
			document.location.href = '/trips/editReservation.php?ID='+document.getElementById('activeItemId').value;
			break;
		case 'L':
			document.location.href = '/trips/editRental.php?ID='+document.getElementById('activeItemId').value;
			break;
	}
}

function confirmDelete(){
	document.getElementById('deleteButtons').style.display = 'none';
	document.getElementById('deleteProgress').style.display = '';
	$.ajax(
		{
			url: "/trips/delete.php?Kind="+document.getElementById('activeItemKind').value+"&ID="+document.getElementById('activeItemId').value,
			success: function(response){
				if( trim(response) != "OK" )
					alert(response);
				reloadPage();
			},
			error: ajaxError
		}
	);
}

function undeletePlan(id){
	document.getElementById('activePlanId').value = id;
	document.getElementById('undeletePlanButtons').style.display = '';
	document.getElementById('undeletePlanProgress').style.display = 'none';
	showPopupWindow(document.getElementById('undeletePlanPopup'));
}

function deletePlan(id){
	document.getElementById('activePlanId').value = id;
	document.getElementById('deletePlanButtons').style.display = '';
	document.getElementById('deletePlanProgress').style.display = 'none';
	showPopupWindow(document.getElementById('deletePlanPopup'));
}

function confirmDeletePlan(){
	document.getElementById('deletePlanButtons').style.display = 'none';
	document.getElementById('deletePlanProgress').style.display = '';
	$.ajax(
		{
			url: "/trips/deletePlan.php?ID="+document.getElementById('activePlanId').value,
			success: function(response){
				if( trim(response) != "OK" )
					alert(response);
				document.location.href = "/trips/"+GETParams;
			},
			error: ajaxError
		}
	);
}

function confirmUndeletePlan(){
	document.getElementById('undeletePlanButtons').style.display = 'none';
	document.getElementById('undeletePlanProgress').style.display = '';
	$.ajax(
		{
			url: "/trips/deletePlan.php?ID="+document.getElementById('activePlanId').value+"&undelete=1",
			success: function(response){
				if( trim(response) != "OK" )
					alert(response);
				document.location.href = "/trips/"+GETParams;
			},
			error: ajaxError
		}
	);
}

function editPlan(planId){
	showFrame('/trips/editPlan.php?ID='+planId, 600, 'Edit plan');
}


function confirmEditPlan(){
	var planName = document.getElementById('editPlanName');
	if( trim(planName.value) == '' ){
		$(planName).animate({left: '+=10'}, 200);
		$(planName).animate({left: '-=20'}, 200);
		$(planName).animate({left: '+=10'}, 200);
		setTimeout( "document.getElementById('editPlanName').focus()", 1100 );
		return false;
	}
	document.getElementById('editPlanButtons').style.display = 'none';
	document.getElementById('editPlanProgress').style.display = '';
	$.ajax(
		{
			url: "/trips/updatePlan.php?TravelPlanID="+document.getElementById('activePlanId').value+"&Name="+url_encode(planName.value),
			dataType: 'json',
			success: function(response){
				if( response.Status != "OK" ){
					document.getElementById('editPlanProgress').style.display = 'none';
					document.getElementById('editPlanButtons').style.display = '';
					document.getElementById('editPlanName').focus();
					alert(response.Message);
				}
				document.getElementById('head'+response.PlanID).innerHTML = response.Name;
				cancelPopup();
			},
			error: ajaxError
		}
	);
}

function moveToChanged(){
	var moveTo = document.getElementById('moveTo');
	if( moveTo.value == "new" ){
		activePopupWindow.style.visibility = 'hidden';
        var matches = window.location.href.match(/CurrentUserAgentID\=(\d+)/);
        if(matches)
            var CurrentUserAgentID = '&CurrentUserAgentID='+matches[1];

		showFrame('/trips/editPlan.php?ID=0&Move=1&ItemID='+document.getElementById('activeItemId').value+'&ItemKind='+document.getElementById('activeItemKind').value+CurrentUserAgentID, 600, "Create new plan");
	}
}

function confirmMove(){
	var moveTo = document.getElementById('moveTo');
	var planName = document.getElementById('planName');
	if( moveTo.style.display == 'none' ){
		// create new plan
		if( trim(planName.value) == '' ){
			$(planName).animate({left: '+=10'}, 200);
			$(planName).animate({left: '-=20'}, 200);
			$(planName).animate({left: '+=10'}, 200);
			setTimeout( "document.getElementById('planName').focus()", 1100 );
			return false;
		}
	}
	else{
		// move to existing
		if( moveTo.value == "" ){
			$(moveTo).animate({left: '+=10'}, 200);
			$(moveTo).animate({left: '-=20'}, 200);
			$(moveTo).animate({left: '+=10'}, 200);
			setTimeout( "document.getElementById('moveTo').focus()", 1100 );
			return false;
		}
	}
	document.getElementById('moveButtons').style.display = 'none';
	document.getElementById('moveProgress').style.display = '';
	moveSegment(moveTo.value, planName.value, document.getElementById('copyInsteadMove').checked);
}

function moveSegment(planId, planName, copy){
	$.ajax(
		{
			url: "/trips/move.php",
			type: "POST",
			data: {
				Kind: document.getElementById('activeItemKind').value,
				ID: document.getElementById('activeItemId').value,
				TravelPlanID: planId,
				Name: planName,
				Copy: copy
			},
			success: function(response){
				if( trim(response) != "OK" )
					alert("'"+response+"'");
				reloadPage();
			},
			error: ajaxError
		}
	);
}

function switchBlock(id){
	var switcher = document.getElementById('switcher'+id);
	var block = document.getElementById(id);
	var table = document.getElementById('table'+id);
	if( switcher.src.indexOf('open') > 0 ){
		// close
		block.style.overflow = 'hidden';
		$(block).animate({height: 50}, 500);
		switcher.src = switcher.src.replace(/open/, 'close');
	}else{
		// open
		switcher.src = switcher.src.replace(/close/, 'open');
		$(block).animate({height: $(table).height()}, 500);
	}
}

function showSegment(kind, id){
	$.ajax(
		{
			url: "/trips/showSegment.php?Kind="+kind+"&ID="+id,
			success: function(response){
				document.getElementById('framePopup').style.width = '850px';
				showHTML(response);
				var re = new RegExp("eval (.+) endeval", "im");
				var arr = re.exec(response);
				if(arr.length > 0){
					setTimeout(arr[1], 1000);
				}
			},
			error: ajaxError
		}
	);
}

function showHTML(html){
	var container = document.getElementById('popupFrameContainer');
	var popup = document.getElementById('framePopup');
	container.style.height = '';
	container.innerHTML = html;
	var height = $(container).height();
	if( height > 600 )
		height = 600;
	if( height < 100 )
		height = 100;
	popup.style.height = height + 20 + 'px';
	container.style.height = height + 'px';
	container.style.overflow = 'auto';
	document.getElementById('framePopupDiv').style.height = height + 20 + 'px';
	showPopupWindow(popup);
}

function addPlans(travelPlanId){
	document.getElementById('activePlanId').value = travelPlanId;
	showPopupWindow(document.getElementById('addPlansPopup'));
}

function selectPlanType(){
	hidePopupWindow();
	showPopupWindow(document.getElementById('selectPlanTypePopup'), true);
}

function showDirections(id, from, to, mapId, directionsId, fromName, toName, travelPlanID) {
	var rendererOptions = {
		draggable: false
	};
	var directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);;
	var directionsService = new google.maps.DirectionsService();
	var map;
	var coordFrom = from.replace(/\@/g, "").split(",");
	var coordTo = to.replace(/\@/g, "").split(",");
	if (coordFrom.length != 2)
		coordFrom = from;
	else
		coordFrom = new google.maps.LatLng(coordFrom[0], coordFrom[1]);
	if (coordTo.length != 2)
		coordTo = to;
	else
		coordTo = new google.maps.LatLng(coordTo[0], coordTo[1]);

	function initialize() {
		var myOptions = {
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
		map = new google.maps.Map(document.getElementById(mapId), myOptions);
		directionsDisplay.setMap(map);
		directionsDisplay.setPanel(document.getElementById(directionsId));

		calcRoute(coordFrom, coordTo);
	}

	function calcRoute(start, end, unknownError) {
		if (unknownError === undefined) 
			unknownError = false;
		var request = {
			origin: start,
			destination: end,
			travelMode: google.maps.TravelMode.DRIVING
		};
		directionsService.route(request, function(response, status) {
			if (status == google.maps.DirectionsStatus.OK) {
				if(response.routes.length > 0 && response.routes[0].legs.length > 0){
					response.routes[0].legs[0].start_address = fromName;
					response.routes[0].legs[0].end_address = toName;
				}
				directionsDisplay.setDirections(response);
			} else {
				if (!unknownError)
					calcRoute(fromName, toName, true);
				else {
					document.getElementById(directionsId).innerHTML = "Could not calculate driving directions";
				}
			}
		});
	}

	initialize();
}

function saveShare(){
	var form = document.getElementById('shareForm');
	var agents = new Object();
	for(var n = 0; n < form.length; n++){
		var input = form[n];
		if((input.type == 'checkbox') && input.checked)
			agents['ua'+n] = input.value;
	}
	document.getElementById('shareMessage').style.display = 'none';
	$.ajax(
		{
			url: '/trips/saveShare.php?TravelPlanID='+form.TravelPlanID.value,
			type: 'POST',
			data: agents,
			success: function(response){
				if(trim(response) != 'OK'){
					document.getElementById('shareMessage').innerHTML = response;
					document.getElementById('shareMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('shareMessage').innerHTML = 'Changes saved';
					document.getElementById('shareMessage').className = 'successFrm';
				}
//				document.getElementById('shareMessage').style.display = '';
				$('#shareMessage').fadeIn();
			},
			error:ajaxError
		}
	);
}

function emailPlan(){
	var mails = trim(document.getElementById('Emails').value);
	var form = document.getElementById('shareForm');
	var params = new Object();
	params["Emails"] = mails;
	$.ajax({
		url: '/trips/emailPlan.php?TravelPlanID='+form.TravelPlanID.value,
		type: 'POST',
		data: params,
		success: function(response){
			if(trim(response) != 'OK'){
				document.getElementById('mailMessage').innerHTML = response;
				document.getElementById('mailMessage').className = 'errorFrm';
			}
			else{
				document.getElementById('mailMessage').innerHTML = 'Email sent';
				document.getElementById('mailMessage').className = 'successFrm';
			}
//				document.getElementById('shareMessage').style.display = '';
			$('#mailMessage').fadeIn();
		},
		error:ajaxError
	});
}

/*function linkEmailPlan(){
	document.getElementById('linkMailMessage').style.display = 'none';
	var mails = trim(document.getElementById('linkEmails').value);
	if(mails == ''){
		alert('Please enter at least one email'); 
		document.getElementById('linkEmails').focus();
		return;
	}
	var params = new Object();
	params["Emails"] = mails;
	$.ajax(
		{
			url: '/trips/linkEmail.php?TravelPlanID='+document.getElementById('TravelPlanID').value,
			type: 'POST',
			data: params,
			success: function(response){
				if(trim(response) != 'OK'){
					document.getElementById('linkMailMessage').innerHTML = response;
					document.getElementById('linkMailMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('linkMailMessage').innerHTML = 'Email sent';
					document.getElementById('linkMailMessage').className = 'successFrm';
				}
//				document.getElementById('shareMessage').style.display = '';
				$('#linkMailMessage').fadeIn();
			},
			error:ajaxError
		}
	);
}*/

function linkPlanURL(){
	document.getElementById('linkURLMessage').style.display = 'none';
	var url = trim(document.getElementById('linkURL').value);
	if(url == ''){
		alert('Please enter a URL'); /*checked*/
		document.getElementById('linkURL').focus();
		return;
	}
	var params = new Object();
	params["URL"] = url;
	$.ajax(
		{
			url: '/trips/linkURL.php?TravelPlanID='+document.getElementById('TravelPlanID').value,
			type: 'POST',
			data: params,
			success: function(response){
				if(trim(response) != 'OK'){
					document.getElementById('linkURLMessage').innerHTML = response;
					document.getElementById('linkURLMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('linkURLMessage').innerHTML = 'Travel plan was linked, reloading...'; /*checked*/
					document.getElementById('linkURLMessage').className = 'successFrm';
					setTimeout("document.location.href='"+url+"'", 1000);
				}
				$('#linkURLMessage').fadeIn();
			},
			error:ajaxError
		}
	);
}

function linkPlans(){
	var form = document.getElementById('linkForm');
	var users = new Object();
	for(var n = 0; n < form.length; n++){
		var input = form[n];
		if((input.type == 'checkbox') && input.checked)
			users['tp'+input.value] = input.value;
	}
	if(users.length == 0){
		alert('Please select at least one user'); /*checked*/
		return;
	}
	document.getElementById('linkMessage').style.display = 'none';
	$.ajax(
		{
			url: '/trips/linkPlans.php?TravelPlanID='+form.TravelPlanID.value,
			type: 'POST',
			data: users,
			success: function(response){
				if(trim(response) != 'OK'){
					document.getElementById('linkMessage').innerHTML = response;
					document.getElementById('linkMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('linkMessage').innerHTML = 'Invitations sent';
					document.getElementById('linkMessage').className = 'successFrm';
				}
//				document.getElementById('shareMessage').style.display = '';
				$('#linkMessage').fadeIn();
			},
			error:ajaxError
		}
	);
}

function postComment(planId){
	var comment = trim(document.getElementById('comment').value);
	if(comment.length > 14000){
		alert('Comment should be no more than 14000 characters'); /*checked*/
		document.getElementById('comment').focus();
		return false;
	}
	if(comment == ''){
		alert('Comment field should not be empty'); /*checked*/
		document.getElementById('comment').focus();
		return false;
	}
	var params = new Object();
	params["Comment"] = comment;
	params["PostTo"] = document.getElementById('commentPostTo').value;
	document.getElementById('commentMessage').style.display = 'none';
	$.ajax(
		{
			url: '/trips/postComment.php?TravelPlanID='+planId,
			type: 'POST',
			data: params,
			dataType: 'json',
			success: function(response){
				if(response.Status != 'OK'){
					document.getElementById('commentMessage').innerHTML = response.Status;
					document.getElementById('commentMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('commentMessage').innerHTML = 'Comment was posted'; /*checked*/
					document.getElementById('commentMessage').className = 'successFrm';
					document.getElementById('commentsText').innerHTML = response.Comments;
					document.getElementById('comment').value = '';
					document.getElementById('commentCharCount').innerHTML = '14000';
				}
//				document.getElementById('shareMessage').style.display = '';
				$('#commentMessage').fadeIn;
			},
			error:ajaxError
		}
	);
}

function removeComment(planId, commentId){
	if(!window.confirm('Are you sure, you want to remove this comment?')){ /*checked*/
		return false;
	}
	var params = new Object();
	params["CommentID"] = commentId;
	$.ajax(
		{
			url: '/trips/removeComment.php?TravelPlanID='+planId,
			type: 'POST',
			data: params,
			dataType: 'json',
			success: function(response){
				if(response.Status != 'OK'){
					document.getElementById('commentMessage').innerHTML = response.Status;
					document.getElementById('commentMessage').className = 'errorFrm';
				}
				else{
					document.getElementById('commentMessage').innerHTML = 'Comment was removed'; /*checked*/
					document.getElementById('commentMessage').className = 'successFrm';
					document.getElementById('commentsText').innerHTML = response.Comments;
				}
				$('#commentMessage').fadeIn();
			},
			error:ajaxError
		}
	);
}

function commentKeyPress(event){
	var length = document.getElementById('comment').value.length;
	if((event.keyCode >= 32) || (event.keyCode >= 13) || (event.keyCode >= 9))
		if(length >= 14000){
			event.preventDefault();
			return false;
		}
		else
			length++;
	length = 14000 - length;
	if(length < 0)
		length = 0;
	document.getElementById('commentCharCount').innerHTML = length;
	return true;
}

function commentKeyUp(event){
	var length = 14000 - document.getElementById('comment').value.length;
	if(length < 0)
		length = 0;
	document.getElementById('commentCharCount').innerHTML = length;
	return true;
}

function askAccountQuestion(accountId, providerName, question, errorMessage, onSubmit, onCancel){
	var prompt = question;
	if(question != errorMessage)
		prompt = errorMessage + "<br/><br/>" + question;
	showMessagePopup('', providerName+' asks you a security question', prompt+'<br><input class="inputTxt" id="securityAnswer" type="text" style="width:454px;">');
	setTimeout("document.getElementById('securityAnswer').focus(); setAnswerHandler();", 500);
	document.getElementById('messageCancelButton').style.display = "";
	document.getElementById('messageCancelButton').onclick = function(){
		if(onCancel != ""){
		    hidePopupWindow();
			onCancel();
		}
		else
		    cancelPopup();
	};
	document.getElementById('messageOKButton').onclick = function(){
		if(trim(document.getElementById('securityAnswer').value) == ""){
			document.getElementById('securityAnswer').focus();
			$('#securityAnswer').animate({left: '+=10'}, 200);
			$('#securityAnswer').animate({left: '-=20'}, 200);
			$('#securityAnswer').animate({left: '+=10'}, 200);
			return;
		}
		hidePopupWindow();
		var params = new Object();
		params["AccountID"] = accountId;
		params["Question"] = question;
		params["Answer"] = trim(document.getElementById('securityAnswer').value);
		$.ajax(
			{
				url: '/account/securityAnswer.php',
				type: 'POST',
				data: params,
				success: function(response){
					if(response != 'OK'){
						alert(response);
						cancelPopup();
					}
					else{
						onSubmit();
					}
				},
				error:ajaxError
			}
		);
	};
}

function setAnswerHandler(){
	$('#securityAnswer').keypress(function(event){
		if(event.keyCode == 13)
			document.getElementById('messageOKButton').onclick();
	});
	$('#securityAnswer').keydown(function(event){
		if(event.keyCode == '27')
			document.getElementById('messageCancelButton').onclick();
	});
}

jQuery.fn.sort = function() {
	return this.pushStack( [].sort.apply( this, arguments ), []);
};

function compareWidth(a,b){
    return $(a).width() < $(b).width() ? 1 : -1;
};

function alignPlan(){
	$('table.flightSegment td.downLineCorner div').each(function(index, div){
		offset = 1
		if(($.browser.mozilla) && (($(div).parent().height() % 2) == 0))
			offset = 0;
		div.style.height = Math.round($(div.parentNode).height() / 2 - offset) + 'px';
	});
	return;
	// ------- commented out ------------
	// resize horizontally
	var stopped = false;
	var ellipsable = new Array();
	$('div.ellipsis').each(function(index, div){
		ellipsable.push($(div));
	});
	var iterations = 0;
	while(($(document).width() > $(window).width()) && ($(window).width() >= 1250)){
		var truncated = false;
		iterations++;
		ellipsable.sort(compareWidth);
		if(ellipsable.length > 0){
			var first = ellipsable[0];
			var maxWidth = first.width();
		}
		jQuery.each(ellipsable, function(index, div){
//			alert(div.html() + ': before: ' + div.width());
			if(truncated && (div.width() < (maxWidth - 50)))
				return false;
			var text = div.html();
			var words = text.split(" ");
			var result = new Array();
			var haveEllipsis = false;
			var changed = false;
			for(key = words.length - 1; key >= 0; key--){
				var word = words[key];
				if(trim(word) == "")
					continue;
				if(word == "...")
					haveEllipsis = true;
				if((word == "...") || (word.indexOf('(') == 0) || (key <= 1) || changed){
					result[key] = word;
				}
				else{
					if(!haveEllipsis)
						result[key] = "...";
					truncated = true;
					changed = true;
				}
			}
			div.html(result.join(" "));
//			alert(div.html() + ': after: ' + div.width());
			return true;
		});
		if(!truncated)
			break;
	}
}

function alignPlans(){
	var maxWidth = 0;
	var divs = $('#travelPlans div.date');
	divs.each(function(index, div){
		var width = $(div).width();
		if(width > maxWidth)
			maxWidth = width;
	});
	divs.each(function(index, div){
		div.style.minWidth = maxWidth+'px';
	});
}

var accounts;

function addProviderPlan(displayName, providerId, travelPlanId, userAgentID){
	$.ajax({
		url: "/trips/addFrame.php?ID="+providerId+"&TravelPlanID="+travelPlanId+"&UserAgentID="+userAgentID,
		dataType: "json",
		success: function(response){
			accounts = response.accounts;
			showMessagePopup('info', "<div class='limited'>Retrieve "+displayName+ " reservations</div>", response.html, true);
		}
	});
}

var activeTravelPlanId = 0;

function checkAccountsForTrips(accounts, travelPlanId){
	activeTravelPlanId = travelPlanId;
	checkAccountIdx(accounts, 0, true);
	// &BackTo=It&TravelPlanID=
}

function getPlanImages() {
	var failImage = '/images/sampleTrip.png';
	$('img.gcmapimage').each(function(index, element) {
		if ($(element).is(':visible').length > 0) return;
		if ($(element).height() >= 111 /*&& !$.browser.msie*/) {
			var img = document.createElement('img');
			img.src = $(this).attr('src');
			if (img.height >= 111 /*&& !$.browser.msie*/) {
				$(element).css({'visibility': 'visible'});
			} else {
				$(element).attr('src', failImage).css({'visibility': 'visible'});
			}
		} else {
			$(element).attr('src', failImage).css({'visibility': 'visible'});
		}
	});
}

function calendarExport() {
	if (Calendars == null) {
		$.ajax({
			url: "/iCal/getPopupData.json",
			type: "POST",
			data: {},
			dataType: 'json',
			success: function(response) {
				if (response.Count > 1) {
					Calendars = response.Agents;
				}
				else {
					Calendars = {};
					Calendars[-1] = response.Agents[0];
				}
				$('#calendarList').html(response.Content);
				calendarExport();
			}
		});
	}
	else {
		if (typeof(Calendars[-1]) != "undefined") {
			showCalendarLink(-1);
		}
		else {
			showPopupWindow(document.getElementById('selectCalendarPopup'));
		}
	}
}

function switchManage(remove, agent) {
	if (remove) {
		var url = document.location.protocol + '//' + document.location.host + '/iCal/' + Calendars[agent].Code;
		document.getElementById('linkRemovedContainer').style.display = 'none';
		document.getElementById('calendarLinkContainer').style.display = 'block';
		$('#calendarLink').text(url);
		$('#calendarLink').attr('href', url);
		$('#manageButton input').attr('value', 'Remove this iCal link');
		$('#manageButton input').attr('onclick', 'showCalendarLink(' + agent + ', "remove");');

	}
	else {
		document.getElementById('linkRemovedContainer').style.display = 'block';
		document.getElementById('calendarLinkContainer').style.display = 'none';
		$('#manageButton input').attr('value', 'Get new iCal link');
		$('#manageButton input').attr('onclick', 'showAgreePopup(' + agent + ');');
	}
	if (activePopupWindow == null || activePopupWindow.id != 'linkCalendarPopup') {
		showPopupWindow(document.getElementById('linkCalendarPopup'));
	}
}
function showAgreePopup(agent) {
	if (activePopupWindow != null) {
		var backTo = activePopupWindow.id;
		$('#calendarDecline').attr('onclick', "showPopupWindow(document.getElementById('" + backTo + "'));");
	}
	else {
		$('#calendarDecline').attr('onclick', "cancelPopup();");
	}
	$('#calendarAgree').attr('onclick', "showCalendarLink(" + agent + ", 'new');");
	showPopupWindow(document.getElementById('importCalendarPopup'));
}

function showCalendarLink(agent, action) {
	switch (action) {
		case "new":
			$.ajax("/iCal/manage.json", {
				type: "POST",
				data: {agent: agent, operation: "new"},
				success: function(data) {
					if (data.result > 0) {
						Calendars[agent].Code = data.Code;
						showCalendarLink(agent);
					}
					else
						cancelPopup();
				}
			});
			break;
		case "remove":
			$.ajax("/iCal/manage.json", {
				type: "POST",
				data: {agent: agent, operation: "remove"},
				success: function(data) {
					if (data.result > 0) {
						Calendars[agent].Code = '0';
						showCalendarLink(agent);
					}
					else
						cancelPopup();
				}
			});
			break;
		default:
			switch (Calendars[agent].Code) {
				case null:
					showAgreePopup(agent);
					break;
				case "0":
					switchManage(false, agent);
					break;
				default:
					switchManage(true, agent);
					break;
			}
	}
}