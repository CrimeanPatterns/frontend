// inAppPurchase iPhone
var inAppPurchase = function () {
	var self = {};

	self.ProductID = '10';
	self.Loading = false;
	self.ConfirmUrl = '';
	self.CompleteUrl = '';

	self.activity = function (state) {
		if (state) {
			self.Loading = true;
			setTimeout(function () {
				if (self.Loading)
					$.mobile.loading('show');
			}, 10);
		} else {
			self.Loading = false;
			$.mobile.loading('hide');
			$('#purchase-button').button('enable');
		}
	};

	self.init = function () {
		if (typeof window.plugins != 'undefined' && typeof window.plugins.inAppPurchaseManager != 'undefined') {
			logging.log('inAppPurchaseManager', 'plugin found', 'info');

			window.plugins.inAppPurchaseManager.onPurchased = self.onPurchased;
			window.plugins.inAppPurchaseManager.onRestored = self.onRestored;
			window.plugins.inAppPurchaseManager.onFailed = self.onFailed;

			self.activity(true);
			window.plugins.inAppPurchaseManager.requestProductData(self.ProductID, self.onRequestSuccess, self.onRequestFailed);

			$('#purchase-button').click(function (e) {
				e.preventDefault();
				if (!self.Loading) {
					$(this).button('disable');
					self.activity(true);
					window.plugins.inAppPurchaseManager.makePurchase(self.ProductID, 1);
				}
			});

			/*
			 restoreCompletedTransactions()
			 */
		} else {
			logging.log('inAppPurchaseManager', 'plugin NOT found', 'error');
		}
	};

	self.onPurchased = function(transactionIdentifier, productId, transactionReceipt) {
		logging.log('inAppPurchaseManager', 'purchased: ' + productId, 'info');
		if (self.ConfirmUrl == '')
			return false;

		prefetch.Enabled = false;
		prefetch.suspend(true);
		$.ajax({
			url:self.ConfirmUrl,
			data:{
				TransactionID:transactionIdentifier,
				Receipt:transactionReceipt
			},
			dataType:'json',
			cache:false,
			useCache:false,
			type:'POST',
			success:function (data) {
				var back = $('#purchase-back').attr('href');
				if (data.confirmed) {
					prefetch.reload();
					self.afterPurchaseChecked();
					if (self.CompleteUrl != '')
						$.mobile.changePage(self.CompleteUrl);
					else
						$.mobile.changePage(back);
				} else {
					self.afterPurchaseChecked();
					$.mobile.changePage(back);
				}
			},
			error:function(XMLHttpRequest, textStatus, errorThrown){
				logging.log('inAppPurchaseManager', 'check fails', 'error');
				$.mobile.changePage($('#purchase-back').attr('href'));
				self.afterPurchaseChecked();
			}
		});
		return true;
	};

	self.afterPurchaseChecked = function () {
		prefetch.Enabled = true;
		prefetch.suspend(false);
		self.activity(false);
	};

	self.onRestored = function(transactionIdentifier, productId, transactionReceipt) {
		logging.log('inAppPurchaseManager', 'restored: ' + productId, 'info');
		/* See the developer guide for details of what to do with this */
		self.activity(false);
	};

	self.onFailed = function(errno, errtext) {
		logging.log('inAppPurchaseManager', 'failed: ' + errtext, 'error');
		self.activity(false);
		$.mobile.changePage($('#purchase-back').attr('href'));
	};

	self.onRequestSuccess = function(productId, title, description, price) {
		logging.log("inAppPurchaseManager", "productId: " + productId + " title: " + title + " description: " + description + " price: " + price, 'debug');
		$('#purchase-title').text(title);
		$('#purchase-description').text(description);
		$('#purchase-price').text(price);
		$('#purchase-container').show();
		self.activity(false);
	};

	self.onRequestFailed = function(id) {
		logging.log("inAppPurchaseManager", "Invalid product id: " + id, 'error');
		self.activity(false);
		$.mobile.changePage($('#purchase-back').attr('href'));
	};

	return self;
}();
