var logging = function () {
	var self = {};

	self.cache = typeof(localStorage['logging']) != 'undefined' ? JSON.parse(localStorage['logging']) : [];

	self.sending = false;
	self.handle = 0;

	self.levels = {
		error: 3,
		warning: 2,
		info: 1,
		debug: 0
	};

	// printable modules and minimal level for them, other will be printed anyway
	self.modules = {
		prefetch: 'warning',
		cache: 'info',
		ajax: 'info',
		design: 'info',
		localStorage: 'info',
		cacheStorage: 'info'
	};

	self.log = function (module, message, level) {
		if (config.sendLogs && self.handle == 0) {
			self.handle = setInterval(function () {
				if (self.sending) {
					self.send();
				}
			}, 1000 * 60 * 5);
		}

		module = module || 'unknown';
		message = message || 'empty message';
		level = level || 'info';

		if (typeof(message) != 'string') {
			message = JSON.stringify(message);
		}

		if (self.cache.length >= 1000) {
			if (self.sending) {
				self.send();
			} else {
				while (self.cache.length >= 1000) {
					self.cache.shift();
				}
			}
		}

		if(!config.sendLogs)
			self.cache.push({
				time: Math.floor(Date.now()/1000),
				module: module,
				message: message,
				level: level
			});

		// wrong module
		// or wrong min level or wrong cur level
		// or cur level more or equal to min level
		if (typeof(self.modules[module]) == 'undefined' ||
			(typeof(self.modules[module]) != 'undefined' && (typeof(self.levels[self.modules[module]]) == 'undefined' || typeof(self.levels[level]) == 'undefined')) ||
			(typeof(self.modules[module]) != 'undefined' && typeof(self.levels[self.modules[module]]) != 'undefined' &&  typeof(self.levels[level]) != 'undefined' && self.levels[level] >= self.levels[self.modules[module]]))
		{
			console.log('[' + level + '] ' + module + ': ' + message);
		}
	};

	self.send = function() {
		if(!config.sendLogs)
			return;
		console.log('sending log');
		var data = JSON.stringify(self.cache);
		self.cache = [];
		$.ajax({
			url:config.baseHost + '/mobile/logs',
			data: {'log': data},
			dataType:'json',
			cache:false,
			useCache:false,
			type:'POST',
			silent: true,
			success:function (data) {
				console.log('send log: success');
			},
			error:function(XMLHttpRequest, textStatus, errorThrown){
				logging.log('logging', 'fail - '+textStatus+' - '+errorThrown, 'error');
				setTimeout(function () {
					$.ajax({
						url:config.baseHost + '/mobile/logs',
						data: {'log': data},
						dataType:'json',
						cache:false,
						useCache:false,
						type:'POST',
						silent: true,
						success:function (data) {
							console.log('send log: success');
						},
						error:function(XMLHttpRequest, textStatus, errorThrown){
							logging.log('logging', 'second fail - '+textStatus+' - '+errorThrown, 'error');
						}
					});
				}, 10000);
			}
		});
	};

	self.saveCache = function () {
		localStorage.setItem('logging', JSON.stringify(self.cache));
		self.log('logging', 'save cache');
	};

	return self;
}();
