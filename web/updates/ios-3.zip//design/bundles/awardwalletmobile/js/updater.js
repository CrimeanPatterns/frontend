var updater = function(){

	var self = {};

	self.tempDir = null;
	self.persistentDir = null;
	self.updateInProgress = false;

	self.init = function(){
		logging.log('updater', 'init');
		window.requestFileSystem(
			LocalFileSystem.PERSISTENT,
			0,
			function(fileSystem){
				logging.log('updater', 'got persistent filesystem', 'debug');
				logging.log('updater', 'name: ' + fileSystem.name + ', path: ' + fileSystem.root.fullPath, 'debug');
				self.persistentDir = fileSystem.root;
				window.requestFileSystem(
					LocalFileSystem.TEMPORARY,
					0,
					function(fileSystem){
						logging.log('updater', 'got temp filesystem', 'debug');
						logging.log('updater', 'name: ' + fileSystem.name + ', path: ' + fileSystem.root.fullPath, 'debug');
						self.tempDir = fileSystem.root;
						logging.log('updater', 'starting');
						setInterval(self.check, 86400 * 1000);
						self.check();
					},
					function(error){
						logging.log('updater', 'failed to get temporary filesystem: ' + error, 'error');
					}
				);
			},
			function(error){
				logging.log('updater', 'failed to get persistent filesystem: ' + error, 'error');
			}
		);
	};

	self.check = function(){
		if (self.updateInProgress) {
			logging.log('updater', 'update in progress');
			return;
		}
		self.updateInProgress = true;
		prefetch.suspend(true);
		logging.log('updater', 'checking for new version');
		var data = {
			device: config.device,
			mobileVersion: config.mobileVersion, 
			rootPath: self.tempDir.fullPath
		};
		logging.log('updater', 'current state: ' + JSON.stringify(data));
		$.ajax({
			url:config.baseHost + '/mobile/checkForUpdates',
			data: data,
			dataType: 'json',
			cache: false,
			useCache: false,
			type: 'POST',
			silent: true,
			success: function (data) {
				console.log(data);
				logging.log('updater', 'got response: ' + JSON.stringify(data), 'debug');
				if (typeof data.haveUpdate != 'undefined') {
					if (data.haveUpdate) {
						self.downloadUpdate(data);
					} else {
						logging.log('updater', 'no updates');
						prefetch.suspend(false);
						self.updateInProgress = false;
					}
				} else {
					logging.log('updater', 'invalid response', 'error');
					prefetch.suspend(false);
					self.updateInProgress = false;
				}
			},

			error: function(XMLHttpRequest, textStatus, errorThrown){
				logging.log('updater', 'error in response: ' + textStatus + ', ' + errorThrown, 'error');
				prefetch.suspend(false);
				self.updateInProgress = false;
			}
		});
	};

	self.downloadUpdate = function(data){
		prefetch.stop();
		progressBar.progress(0);
		var zipPath =  self.tempDir.fullPath + '/update.zip';
		logging.log('updater', 'downloading: ' + data.downloadLink + ' to ' + zipPath);
		var ft = new FileTransfer();
		var step = 0;
		ft.onprogress = function (progressEvent) {
			if ((++step) % 5 == 0) {
				if (progressEvent.lengthComputable) {
					progressBar.progress(progressEvent.loaded / progressEvent.total * 100);
				} else {
					//just move forward
					progressBar.progress(step);
				}
			}
		};
		ft.download(
			config.baseHost + data.downloadLink,
		    zipPath,
		    function(entry) {
		        logging.log("updater", "download complete: " + entry.fullPath);
				progressBar.progress(100);
				self.getEmptyDir(data.version, function(updatePath){
					logging.log("updater", "extracting to " + updatePath);
					window.plugins.extractZipFile.extractFile(
						entry.fullPath,
						updatePath,
						function(){
							logging.log("updater", "extracted");
							self.openUpdate(updatePath);
						},
						function(error){
							logging.log("updater", error, "error");
							self.updateInProgress = false;
						}
					);
				});
		    },
		    function(error) {
		        logging.log("updater", "download error source " + error.source + ', ' + error.target + ", " + error.code);
				prefetch.suspend(false);
				setTimeout(function () {
					$.mobile.loading('hide');
				}, 0);
				progressBar.progress(0);
				self.updateInProgress = false;
			}
		);
	};

	self.getEmptyDir = function(version, success){
		var path, dir, result;
		if(config.device == 'ios'){
			path = self.tempDir.fullPath + '/../Library/Caches/com.awardwallet.iphone/update' + version;
			dir = self.tempDir;
			result = path;
		}
		if(config.device == 'android'){
			path = 'update' + version;
			dir = self.persistentDir;
			result = self.persistentDir.fullPath + '/' + path;
		}
		logging.log('updater', 'update dir: ' + path + 'result: ' + result);
		dir.getDirectory(
			path,
			{ create: true },
			function(dirEntry){
				logging.log('updater', 'dir exists');
				dirEntry.createReader().readEntries(
					function(entries){
						logging.log('updater', 'entries size: ' + entries.length);
						if(entries.length > 0){
							logging.log('updater', 'not empty, clearing');
							dirEntry.removeRecursively(
								function(){
									logging.log('updater', 'removed, creating empty');
									dir.getDirectory(
											path,
											{ create: true },
											function(dirEntry){
												logging.log('updater', 'created empty');
												success(result);
											},
											function(error){
												logging.log('updater', 'failed to create empty dir', 'error');
											}
									);
								},
								function(error){
									logging.log('updater', 'failed to read dir', 'error');
								}
							);
						}
						else
							success(result);
					},
					function(error){
						logging.log('updater', 'failed to read dir', 'error');
					}
				);
			},
			function(error){
				logging.log('updater', 'failed to get empty dir: ' + JSON.stringify(error), 'error');
			}
		);
	};

	self.openUpdate = function(updatePath){
		logging.log('updater', 'opening update at ' + updatePath);
		logging.log('updater', 'stopping prefetch');
		if (typeof(prefetch) != 'undefined')
			prefetch.stop();
		logging.log('updater', 'clearing cache');
		clearCache();
		self.updateInProgress = false;
		logging.log('updater', 'changing page');
		document.location.href = updatePath + '/mobile/login.html';
	};

	return self;
}();