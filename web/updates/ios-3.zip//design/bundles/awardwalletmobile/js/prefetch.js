// prefetcher module
var prefetch = function () {
	var self = {};

	self.Enabled = true;
	self.WaitFor = 0;
	self.WaitFrom = 0;
	self.CheckLock = false;
	self.Suspend = false;
	self.LinksList = {};
	self.LinksPool = [];
	self.LinksPoolEmptyCount = 0;
	self.Handle = 0;
	self.ChunkSize = 0;
	self.Page = false;
	self.Now = 0;
	self.Index = 0;

	self.init = function (force) {
		if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
			antiPrefetch.load();
		} else
		setTimeout(function () {
			self.Enabled = false;
			clearInterval(self.Handle);

			progressBar.progress(0);

			self.Enabled = true;
			if (!force && typeof(localStorage['prefetchEnabled']) != 'undefined')
				self.Enabled = jQuery.parseJSON(localStorage['prefetchEnabled']); // decode string

			self.Now = 0;
			self.WaitFor = 100;
			self.WaitFrom = Date.now();
			self.CheckFrom = false;
			self.Suspend = false;
			self.LinksList = {};
			self.LinksPool = [];
			self.LinksPoolEmptyCount = 0;
			self.Index = 0;

			self.Handle = setInterval(self.tick, 1000);

			logging.log('prefetch', "init " + (self.Enabled?'enabled':'disabled'), 'info');
		}, 10);
	};

	self.reload = function (force) {
		if (force)
			self.Page = cacheKey(document.URL);
		self.init(force);
		if (self.isWaiting() && !self.Suspend) {
			invalidateCache();
		}
	};

	self.stop = function () {
		self.Enabled = false;
		clearInterval(self.Handle);
		self.LinksList = {};
		progressBar.progress(0);
	};

	self.wait = function (ms, forced) {
		var spans = {
			'check': 2000,
			'internal': 500,
			'abort': 10000,
			'sleep': 600000
		};
		if (typeof ms == 'string') {
			ms = spans[ms];
		}
		if (typeof ms != 'number') {
			logging.log('prefetch', 'WRONG WAIT PARAMETER!!!', 'warning');
			ms = spans['sleep'];
		}
		ms = Math.min(spans['sleep'], ms);
		if (self.WaitFrom + self.WaitFor < Date.now() + ms || forced) {
			self.WaitFrom = Date.now();
			self.WaitFor = ms;
			logging.log('prefetch', 'timeout set to '+ms, 'debug');
		}
	};

	self.isWaiting = function () {
		return (self.WaitFrom + self.WaitFor >= Date.now());
	};

	self.suspend = function (state) {
		if (state == false) {
			self.WaitFrom = Date.now();
		}
		self.Suspend = state;
	};

	self.resetList = function () {
		self.LinksList = {};
		progressBar.progress(0);
	};

	self.check = function (url, noinit, force) {
		getCache(url, function (cache) {
			if (cache.valid && (!self.CheckLock || force) && isOnline() && typeof self.LinksList[url] != 'undefined' && (self.LinksList[url].check || force)) {
				self.CheckLock = true;

				logging.log('prefetch', 'check - '+url, 'info');
				self.suspend(true);
				var sum = cache.content;
				$.ajax({
					url:config.baseHost + '/mobile/prefetch/download',
					data: {'links': [url]},
					dataType:'json',
					cache:false,
					useCache:false,
					type:'POST',
					silent: true,
					success:function (data) {
						if ($.isPlainObject(data.pages)) {
							logging.log('prefetch', 'got check pages', 'info');
							for (var url in data.pages) {
								if (data.pages.hasOwnProperty(url)) {
									if (self.Enabled) {
										if (sum != data.pages[url]) {
											logging.log('prefetch', 'page updated!', 'info');
											if (self.Enabled) {
												setCache(url, data.pages[url], self.LinksList[url].checksum, null, true);
												// recheck all pages
												if (!noinit)
													self.init();
											} else {
												break;
											}
										}
									} else {
										break;
									}
								}
							}
						} else {
							logging.log('prefetch', 'got no check pages', 'error');
						}
						if (typeof data.needlogs == 'boolean') {
							logging.log('prefetch', 'got needlogs ' + data.needlogs, 'info');
							logging.sending = data.needlogs;
						}
						self.CheckLock = false;
						logging.log('prefetch', 'check pages: init - '+!noinit, 'info');
						if (force)
							$.mobile.loading('hide');
						self.suspend(false);
					},

					error:function(XMLHttpRequest, textStatus, errorThrown){
						if (textStatus == 'abort') {
							logging.log('prefetch', 'get check pages aborted', 'info');
							self.wait('abort');
						} else {
							logging.log('prefetch', 'get check pages fail', 'error');
							self.wait('sleep');
						}
						if (force)
							$.mobile.loading('hide');
						self.suspend(false);
						self.CheckLock = false;
					}
				});
			}
		});
	};

	self.tick = function () {
		if (!self.Suspend && isOnline() && !fetchNextFromCache && !self.isWaiting() && self.Enabled && config.prefetchLinks) {
			if (Object.size(self.LinksList) == 0)
				return self.getLinks();
			if(!config.prefetchData)
				return false;

			self.wait('internal');
			self.suspend(true);

			logging.log('prefetch', "links count "+Object.size(self.LinksList), 'info');

			self.Index = 0;
			for (var url in self.LinksList) {
				if (self.LinksList.hasOwnProperty(url)) {
					if (self.LinksPool.length < self.ChunkSize) {
						if (typeof (self.LinksList[url].skip) != 'undefined' && !self.LinksList[url].skip) {
							getCache(url, function (cache) {
								if (cache.valid && isCacheExpired(cache) && self.LinksList[cache.key].checksum != 0 && cache.checksum != 0 && self.LinksList[cache.key].checksum == cache.checksum) {
									// update cache date if checksum ok
									setCache(cache.key, cache.content, cache.checksum);
									logging.log('prefetch', 'update key - '+cache.key, 'debug');
								} else if (!cache.valid || (cache.valid && (isCacheExpired(cache) || self.LinksList[cache.key].checksum != (cache.checksum || 0)))) {
									// add to download task
									self.LinksPool.push(cache.key);
									logging.log('prefetch', 'push link for update', 'debug');
								} else {
									// ok
								}
								self.Index += 1;
							});
						}
					} else {
						break;
					}
				}
			}
			var links = [];
			while (links.length < self.ChunkSize && self.LinksPool.length > 0) {
				links.push(self.LinksPool.shift());
			}
			if (links.length > 0 && typeof(localStorage['prefetchEnabled']) == 'undefined') {
				self.wait('internal');

				progressBar.progress(Math.round(100 * self.Index / Object.size(self.LinksList)), self.Now > 0 ? Date.now() - self.Now - self.WaitFor : self.WaitFor + 5000);
				self.Now = Date.now();

				logging.log('prefetch', 'load '+self.LinksPool, 'info');
				self.suspend(true);
				self.LinksPoolEmptyCount = 0;
				$.ajax({
					url:config.baseHost + '/mobile/prefetch/download',
					xhrpool: 'prefetch',
					data: {'links': links},
					dataType:'json',
					cache:false,
					useCache:false,
					type:'POST',
					silent: true,
					success:function (data) {
						self.suspend(false);
						if ($.isPlainObject(data.pages)) {
							logging.log('prefetch', 'got pages', 'info');
							for (var url in data.pages) {
								if (self.Enabled) {
									setCache(url, data.pages[url], self.LinksList[url].checksum, null, true);
								} else {
									break;
								}
							}
						} else {
							logging.log('prefetch', 'got no pages', 'warning');
						}
						if ($.isArray(data.skip)) {
							logging.log('prefetch', 'got skip pages', 'info');
							for (var i in data.skip) {
								if (typeof(self.LinksList[data.skip[i]]) != 'undefined') {
									self.LinksList[data.skip[i]].skip = true;
								}
							}
						}
						if (typeof data.needlogs == 'boolean') {
							logging.log('prefetch', 'got needlogs ' + data.needlogs, 'info');
							logging.sending = data.needlogs;
						}
					},

					error:function(XMLHttpRequest, textStatus, errorThrown){
						if (textStatus == 'abort') {
							logging.log('prefetch', 'get pages aborted', 'info');
							self.wait('abort');
						} else {
							logging.log('prefetch', 'get pages fail', 'error');
							progressBar.progress(100, self.Now > 0 ? Date.now() - self.Now : self.WaitFor + 5000);
							self.wait('sleep');
						}
						self.suspend(false);
					}
				});
			} else {
				if (self.Index >= Object.size(self.LinksList)) {
					progressBar.progress(100, self.Now > 0 ? Date.now() - self.Now : self.WaitFor + 5000);
					self.wait('sleep');
				} else {
					if (self.LinksPoolEmptyCount <= 0)
						self.LinksPoolEmptyCount = 1;
					if (1000 * self.LinksPoolEmptyCount < 600000)
						self.LinksPoolEmptyCount *= 2;
					logging.log('prefetch', "no links pool: "+self.LinksPoolEmptyCount, 'debug');
					self.wait(1000 * self.LinksPoolEmptyCount);
				}
				self.suspend(false);
			}
		}
		return true;
	};

	self.cleanCache = function() {
		logging.log('prefetch', 'cache cleaning', 'info');
		cacheStorage.clearExcluded(self.LinksList);
	};

	self.getLinks = function () {
		if (localStorage['PHPSESSID']) {
			logging.log('prefetch', 'geting links', 'info');
			self.suspend(true);
			$.ajax({
				url:config.baseHost + '/mobile/prefetch/links',
				xhrpool: 'global', // shoud not be just aborted
				dataType:'json',
				cache:false,
				useCache:false,
				type:'POST',
				silent: true,
				success:function (data) {
					if (typeof data.links != 'undefined') {
						logging.log('prefetch', 'got links ' + Object.size(data.links), 'info');
						self.LinksList = data.links;
						if(config.prefetchData)
							self.cleanCache();
						if (self.Page) {
							logging.log('prefetch', 'force check key: '+self.Page, 'info');
							self.check(self.Page, true, true);
							self.wait('check');
							self.Page = false;
						} else {
							var key = cacheKey(document.URL);
							if ((typeof(self.LinksList[key]) != 'undefined' && self.LinksList[key].check) || self.LinksList[key].checksum == 0) {
								logging.log('prefetch', 'check key: '+key, 'info');
								self.check(key, true);
								self.wait('check');
							}
						}
					} else {
						logging.log('prefetch', 'got no links', 'error');
					}
					if (typeof data.chunkSize == 'number') {
						logging.log('prefetch', 'got chunksize ' + data.chunkSize, 'info');
						self.ChunkSize = data.chunkSize;
					} else {
						logging.log('prefetch', 'got no chunksize', 'error');
					}
					if (typeof data.needlogs == 'boolean') {
						logging.log('prefetch', 'got needlogs ' + data.needlogs, 'info');
						logging.sending = data.needlogs;
					}
					self.suspend(false);
				},

				error:function(XMLHttpRequest, textStatus, errorThrown){
					logging.log('prefetch', 'get links fail', 'error');
					progressBar.progress(0);
					self.wait('sleep');
					self.suspend(false);
				}
			});
		} else {
			logging.log('prefetch', "sleep", 'info');
			progressBar.progress(0);
			self.wait('sleep');
		}
		return true;
	};

	return self;
}();

var progressBar = function () {
	var self = {};

	$(document).ready(function () {
		self.Node = $('#progress-bar');
		if (self.Node) {
			self.Node.css('width', '100%');
			self.Width = self.Node.width();
			self.Node.css('width', 0);
			self.Node.parent().hide();
		}
	});

	self.progress = function (percent, ms) {
		if (self.Node) {
			if (percent < 0) percent = 0;
			if (percent > 100) percent = 100;
			if (typeof(ms) != 'string') {
				if (ms < 0) ms = 0;
				if (ms > 30000) ms = 30000;
			}
			var pixels = Math.round(percent / 100 * self.Width);
			var speed = (self.Node.width() == pixels) ? 0 : (ms || 'slow');
			if (speed != 0) {
				self.Node.parent().fadeIn();
			}
			if (percent == 100) {
				speed = 'slow';
			}
			logging.log('progress', 'change from '+self.Node.width()+'px to '+pixels+'px, speed: '+speed, 'info');
			if (self.Node.width() > pixels && pixels != 0) {
				logging.log('progress', 'negative progress disabled', 'warning');
				return;
			}
			self.Node.animate({
				width: pixels+'px'
			}, speed, function () {
				if (percent == 0 || percent == 100) {
					self.Node.parent().fadeOut();
				}
			});
		}
	};

	self.state = function (state) {
		if (self.Node) {
			self.Node.css('background-color', state ? '#6495ED' : '#A9A9A9');
		}
	};

	return self;
}();
