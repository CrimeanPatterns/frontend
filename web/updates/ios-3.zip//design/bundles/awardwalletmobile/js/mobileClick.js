function showA(selector, width, height) {
    var sizes = getMMASize(width, height);
    var strategy = new SmaatoStrategy({
        'pub': 923865383,
        'adspace': 65769709,
        'width': sizes[0],
        'height': sizes[1]
    });
    var strategy2 = new TapitStrategy({
        'zone': 15356,
        'source': 'device',
        'mode': null,
        'width': sizes[0],
        'height': sizes[1]
    });
	var isFirst = (Math.random() > 0.5);
    window['ad'] = new MobileAds(isFirst ? strategy : strategy2, {
        'adsSelector': selector,
        'reload': 0,
        'alternativeStrategy': !isFirst ? strategy : strategy2,
        'successCallback': function(a) {
            a.defaultConfig.adsSelector.show();
        }
    });
    ad.showAds();
}

function getMMASize(width, height) {
    if (width >= 320)
        return [320, 50];
    if (width >= 300) {
        if (height >= 75)
            return [300, 75];
        else
            return [300, 50];
    }
    if (width >= 216) {
        if (height >= 54)
            return [216, 54];
        else
            return [216, 36];
    }
    if (width >= 168) {
        if (height >= 42)
            return [168, 42];
        else
            return [168, 28];
    }
    if (width >= 120) {
        if (height >= 30)
            return [120, 30];
        else
            return [120, 20];
    }
    return [width, height];
}

function MobileAds(strategy, config) {
    this.strategy = strategy;
    this.current_link = '';
    this.current_content = '';
    this.defaultConfig = {
        'successCallback': function(a){},
        'adsSelector': null,
        'reload': 30000,
        'alternativeStrategy': null
    };
    this.reloadHandler = null;
    if (typeof(config) == 'undefined')
        config = {};
    $.extend(this.defaultConfig, config);

    var a = this;
    this.showAds = function() {
        var handler = function() {
            a.display(a.defaultConfig.adsSelector, a.current_content);
            a.defaultConfig.successCallback(a);
            if (a.defaultConfig.reload > 0)
                this.reloadHandler = setInterval(function() { a.reload() }, a.defaultConfig.reload);
        };
        try {
            a.current_link = a.strategy.getLink();
            a.request(a.current_link, function(data) {
                a.current_content = a.strategy.getAds(data);
                if ($.trim(a.current_content) == '' && a.defaultConfig.alternativeStrategy != null) {
                    var alts = a.defaultConfig.alternativeStrategy;
                    var alt_link = alts.getLink();
                    a.request(alt_link, function(data) {
                        a.current_content = alts.getAds(data);
						if ($.trim(a.current_content) != '') {
							handler();
						}
                    });
                    return;
                }
                handler();
            });
        } catch(error) {
            console.log(error);
        }
    };
    this.request = function(link, successCall) {
        $.ajax({
            url: link,
            //dataType: "script",
			silent: true,
            success: function(data) {
                successCall(data);
            }
        });
    };
    this.display = function(selector, content) {
        selector.animate({'opacity': 0}, 200, function(){
            selector.html(content);
            selector.animate({'opacity':1}, 200);
        });
    };
    this.reload = function() {
        try {
            a.request(a.current_link, function(data) {
                a.current_content = a.strategy.getAds(data);
                if ($.trim(a.current_content) == '' && a.defaultConfig.alternativeStrategy != null) {
                    var alts = a.defaultConfig.alternativeStrategy;
                    var alt_link = alts.getLink();
                    a.request(alt_link, function(data) {
                        a.current_content = alts.getAds(data);
						if ($.trim(a.current_content) != '') {
							a.display(a.defaultConfig.adsSelector, a.current_content);
						}
                    });
                    return;
                }
                a.display(a.defaultConfig.adsSelector, a.current_content);
            });
        } catch(error) {

        }
    };

}

function SmaatoStrategy(config) {
    var s = this;
    this.ad = null;
    this.defaultConfig = {
        'response': 'JSONP',
        'divid': (Math.random() + "").slice(2),
        'client': 'adtag100',//somaapi-400
        'formatstrict': 'true',
        'format': 'IMG',
        'pub': 0,
        'adspace': 0,
        'qs': null,
        'kws': null,
        'city': null,
        'zip': null,
        'age': null,
        'latitude': null,
        'longitude': null,
        'device': navigator.userAgent,
        'height': 300,
        'width': 50
    };
    if (typeof(config) == 'undefined')
        config = {};
    $.extend(this.defaultConfig, config);
    this.SomaTag = function() {
        this.displayAd = function(ad) {
            s.ad = ad;
        }
    };
    window['SomaTag'] = new this.SomaTag()

    this.getLink = function() {
        var f = null,
            g = null;
        var b = "http://soma.smaato.net/oapi/reqAd.jsp?";
        b += "response=" + s.defaultConfig.response;
        b += "&divid=" + s.defaultConfig.divid;
        b += "&client=" + s.defaultConfig.client;
        b += "&formatstrict=" + s.defaultConfig.formatstrict;
        b += "&format=" + s.defaultConfig.format;
        b += "&pub=" + s.defaultConfig.pub;
        b += "&adspace=" + s.defaultConfig.adspace;
        if (s.defaultConfig.qs != null) b += "&qs=" + s.defaultConfig.qs;
        if (s.defaultConfig.kws != null) b += "&kws=" + s.defaultConfig.kws;
        if (s.defaultConfig.city != null) b += "&city=" + s.defaultConfig.city;
        if (s.defaultConfig.zip != null) b += "&zip=" + s.defaultConfig.zip;
        if (s.defaultConfig.age != null) b += "&age=" + s.defaultConfig.age;
        if (s.defaultConfig.device != null) b += "&device=" + encodeURIComponent(s.defaultConfig.device);
        if (s.defaultConfig.height != null) b += "&height=" + s.defaultConfig.height;
        if (s.defaultConfig.width != null) b += "&width=" + s.defaultConfig.width;
        if (s.defaultConfig.latitude != null && s.defaultConfig.longitude != null)
            b += "&gps=" + s.defaultConfig.latitude + "," + s.defaultConfig.longitude;

        f || (f = s.getCookie("SomaSession"));
        f || (f = s.getHash(), s.setCookie("SomaSession", f, 0));
        b += "&session=" + f;
        g || (g = s.getCookie("SomaUser"));
        g || (g = s.getHash(), s.setCookie("SomaUser", g, 365));
        b += "&ownid=" + g;
        return b;
    };
    this.getAds = function() {
        if (typeof(s.ad.status) == 'undefined') {
            throw 'unknown error';
        }
        if (s.ad.status == 'ERROR' && s.ad.errorMessage == 'Currently no ad available')
            return '';
        if (s.ad.status !== 'SUCCESS')
            throw s.ad.errorMessage;
        if (s.ad.type === 'IMG') {
            return '<div style="text-align: center;"><a href="'+s.ad.target+'" target="_blank" rel="external"><img src="'+s.ad.link+'" /></a></div>';
        }
        throw "This type is not supported ("+s.ad.type+")";
    };

    this.getHash = function() {
        var a = function () {
            return ((1 + Math.random()) * 65536 | 0).toString(16).substring(1)
        };
        return a() + a() + "-" + a() + "-" + a() + "-" + a() + "-" + a() + a() + a()
    };
    this.setCookie = function(name, value, expire) {
        try {
            if (expire) {
                var d = new Date;
                d.setTime(d.getTime() + expire * 864E5);
                var e = "; expires=" + d.toGMTString()
            } else e = "";
            document.cookie = name + "=" + value + e + "; path=/"
        } catch (f) {}
    };
    this.getCookie = function(name) {
        try {
            name += "=";
            for (var c = document.cookie.split(";"), b = 0; b < c.length; b++) {
                for (var d = c[b]; d.charAt(0) == " ";) d = d.substring(1, d.length);
                if (d.indexOf(name) == 0) return d.substring(name.length, d.length)
            }
        } catch (e) {}
        return null
    };
}

function TapitStrategy(config) {
    var s = this;
    this.ad = null;
    this.defaultConfig = {
        'zone': 0,
        'udid': null,
        'source': null,
        'mode': 'live',
        'width': 300,
        'height': 50,
		'ua': navigator.userAgent,
        'adtype': null,
        'keywords': null,
        'latitude': null,
        'longitude': null,
		'format': 'json'
    };
    if (typeof(config) == 'undefined')
        config = {};
    $.extend(this.defaultConfig, config);
    window['addisplay'] = function(ad) {s.ad = ad};

    this.getLink = function() {
        var link = "http://r.tapit.com/adrequest.php?zone=" + s.defaultConfig.zone;
        if (s.defaultConfig.udid != null) link += "&udid=" + encodeURIComponent(s.defaultConfig.udid);
        if (s.defaultConfig.source != null) link += "&source=" + encodeURIComponent(s.defaultConfig.source);
        if (s.defaultConfig.mode != null) link += "&mode=" + encodeURIComponent(s.defaultConfig.mode);
        if (s.defaultConfig.width != null) link += "&w=" + encodeURIComponent(s.defaultConfig.width);
        if (s.defaultConfig.height != null) link += "&h=" + encodeURIComponent(s.defaultConfig.height);
        if (s.defaultConfig.ua != null) link += "&ua=" + encodeURIComponent(s.defaultConfig.ua);
        if (s.defaultConfig.adtype != null) link += "&adtype=" + encodeURIComponent(s.defaultConfig.adtype);
        if (s.defaultConfig.keywords != null) link += "&=" + encodeURIComponent(s.defaultConfig.keywords);
        if (s.defaultConfig.latitude != null) link += "&lat=" + encodeURIComponent(s.defaultConfig.latitude);
        if (s.defaultConfig.longitude != null) link += "&long=" + encodeURIComponent(s.defaultConfig.longitude);
        if (s.defaultConfig.format != null) link += "&format=" + encodeURIComponent(s.defaultConfig.format);
        return link;
    };
	this.getAds = function(data) {
		if (typeof(data) == 'string')
			data = jQuery.parseJSON(data);
		s.ad = data;
		if (typeof(s.ad.error) != 'undefined') {
			if (s.ad.error == 'No available creatives') {
				return '';
			}
			throw s.ad.error;
		}
		if (typeof(s.ad.type) == 'undefined') {
			throw 'unknown error';
		}
		if (typeof(s.ad.type) == 'string' && s.ad.type == 'html') {
			var html = s.ad.html;
			var matches;
			matches = html.match(/<a href="([^"]+)"/);
			if (matches[1]) {
				s.ad.clickurl = matches[1];
			}
			matches = html.match(/<img src="([^"]+)"/);
			if (matches[1]) {
				s.ad.imageurl = matches[1];
			}
		}
		if (typeof(s.ad.clickurl) != 'undefined' && typeof(s.ad.imageurl) != 'undefined') {
			return '<div style="text-align: center;"><a href="'+s.ad.clickurl+'" target="_blank" rel="external"><img src="'+s.ad.imageurl+'" /></a></div>';
		}
		throw "This type is not supported ("+s.ad.type+")";
	};
}