var antiPrefetch = function () {
	var self = {};

	self.LastLoad = 0;
	self.UpdateLock = false;

	self.Data = null;
	self.Template = null;

	self.DataKey = 'antiPrefetchData';
	self.TemplateKey = 'antiPrefetchTemplate';

	self.init = function () {
		self.Data = typeof(localStorage[self.DataKey]) == 'string' ? JSON.parse(localStorage[self.DataKey]) : null;
		self.Template = typeof(localStorage[self.TemplateKey]) == 'string' ? JSON.parse(localStorage[self.TemplateKey]) : null;
	};

	self.check = function () {
		if (Date.now() - self.LastLoad > 1000 * 60 * 60) {
			self.load();
		}
	};

	self.render = function (url) {
		self.check();
		if (typeof(self.Data) == 'object' && self.Data && typeof(self.Template) == 'object' && self.Template && typeof(self.Data[url]) != 'undefined' && typeof(self.Template[url]) != 'undefined') {
			console.log('proxy url: '+url);
			var template = self.Template[url];
			if (typeof(self.Template[template]) != 'ubdefined')
				template = self.Template[template];
			return twig({ data: template }).render(self.Data[url]);
		}
		return null;
	};

	self.load = function (reload) {
		if (self.UpdateLock) {
			return;
		}
		self.UpdateLock = true;
		progressBar.progress(80, 'slow');
		console.log('proxy setup...');
		$.when(
			$.ajax({
				url:config.baseHost + '/mobile/json/data',
				dataType:'json',
				cache:false,
				useCache:false,
				type:'POST',
				//silent: true,
				success:function (data) {
					console.log('proxy get data');
					self.Data = data;
					localStorage[self.DataKey] = JSON.stringify(self.Data);
					self.avatars();
					progressBar.progress(90, 'slow');
				}
			}),
			$.ajax({
				url:config.baseHost + '/mobile/json/templates',
				dataType:'json',
				cache:false,
				useCache:false,
				type:'POST',
				//silent: true,
				success:function (data) {
					console.log('proxy get templates');
					self.Template = data;
					localStorage[self.TemplateKey] = JSON.stringify(self.Template);
					progressBar.progress(90, 'slow');
				}
			})
		).then(function () {
			self.LastLoad = Date.now();
			progressBar.progress(100);
			progressBar.progress(0, 1);
			$('#list-page.persistent').detach();
			if (reload) {
				$.mobile.changePage(cacheKey(document.URL), {
					allowSamePageTransition: true,
					reloadPage: true
				});
			}
			self.UpdateLock = false;
		}, function () {
			progressBar.progress(0, 1);
			self.UpdateLock = false;
		});
	};

	self.avatars = function () {
		for (var url in self.Data) {
			if (self.Data.hasOwnProperty(url)) {
				var item = self.Data[url];
				if (typeof(item['travelPlan']) != 'undefined' && typeof(item['travelPlan']['TravelPlanID']) != 'undefined' && typeof(item['travelPlanImage']) == 'string') {
					var name = 'ava' + item['travelPlan']['TravelPlanID'];
					console.log('encode image for '+name+': '+item['travelPlanImage']);
					encodeImage(item['travelPlanImage'], function (data, success, name) {
						if (success) {
							cacheStorage.setItem(name, data);
						}
					}, name);
				}
			}
		}
	};

	self.test = function () {
		if (typeof(self.Data) == 'object' && typeof(self.Template) == 'object') {
			for (var url in self.Data) {
				if (self.Data.hasOwnProperty(url)) {
					var content = self.render(url);
					console.log('content length: ' + content.length);
				}
			}
		} else {
			console.log('setup first!');
		}
	};

	return self;
}();
