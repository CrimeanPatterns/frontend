function toogleInfoTrip(id){
	if(os != 'android'){
		$('#' + id + ' div[rel=secondInfoButton]').slideUp(300);
		$('#' + id + ' div[rel=secondInfo]').slideDown(300);
	} else {
		$('#' + id + ' div[rel=secondInfoButton]').hide();
		$('#' + id + ' div[rel=secondInfo]').show();
	}

}
function pageChanged(e, data){
	var oldPages = $('body').children('div[data-role=page], div[data-role=dialog]').not('.persistent');
	if(oldPages.length > 1){
		var toRemove = oldPages.not(':last');
		toRemove.detach();
	}
}

function cancelDialog(dialog, lastPage){
	if (dialog)
		dialog.removeClass('ui-page-active');
	if (lastPage)
		lastPage.addClass('ui-page-active');
}

function updateTravelPlanFunc(page, patternLink) {
	var page2 = $('#' + page);
	var id = $(page2).attr('data-trip-id');
	var kind = $(page2).attr('data-kind');
	var canUpdate = $(page2).attr('data-can-update');
	if ($.inArray(kind, ['T', 'R', 'E', 'L']) == -1 || canUpdate == 'false') {
		$('.update-travel-plan').addClass('ui-disabled');
		return;
	}
	$('.update-travel-plan').removeClass('ui-disabled');
	var link = patternLink.replace("T", kind).replace("000", id);
	$('.update-travel-plan').attr('href', link);
}

/**
 * this function will suggest back link based on history
 * fallback to default link
 * @param link
 * @return {*}
 * @param backPattern
 * @param deep
 */
function backLink(link, backPattern, deep) {
	var historyLength = $.mobile.urlHistory.stack.length;
	if (typeof(deep) == 'undefined' || deep == -1)
		deep = 0;
	else
		deep = historyLength - (deep + 1);
	if (deep < 0)
		deep = 0;
	for (var i = historyLength - 1; i >= deep; i--) {
		var url = $.mobile.urlHistory.stack[i].url;
		if (typeof(url) == 'string' && url.indexOf('/mobile/') >= 0 &&
			backPattern.test(url) &&
			url.indexOf('&ui-state=dialog') <= 0) {
			logging.log('design', 'set back link: ' + url + ', matched ' + backPattern, 'debug');
			return url;
		}
	}
	return link;
}

function initBackLinks() { // not so dirty hack
	var deep;
	$('a.backLink').each(function(index, elem){
		elem = $(elem);
		deep = (typeof(elem.data('backdeep')) != 'undefined') ? elem.data('backdeep') : -1;
		if (typeof (elem.attr('href')) != 'undefined') {
			elem.attr('href', backLink(elem.attr('href'), new RegExp(elem.data('backlink')), deep));
			//elem.removeClass('backLink');
		}
	});
}

$(document).bind('pagebeforeshow', function() {
	initBackLinks();
});

$(document).live('pagebeforeshow', function() {
	$('a[href^="http"]').each(function (index, elem) {
		elem = $(elem);
		if (elem.attr('href').indexOf('awardwallet') == -1 && elem.attr('href').indexOf('mobile') == -1 && typeof (elem.attr('target')) == 'undefined') {
			elem.attr('target', '_blank');
			logging.log('design', 'link: '+elem.attr('href')+' became external!', 'info');
		}
		logging.log('design', 'link: '+elem.attr('href')+' is ok: '+elem.attr('href').indexOf('awardwallet')+' '+elem.attr('href').indexOf('mobile')+' '+elem.attr('target'), 'debug');
	});
});

function showNumberPopup(id) {
	$(window).off('orientationchange').on('orientationchange', function(event, ui) {
		showNumberPopup(id);
	});
	$('#barcodePopup').attr('src', $('#barcode').attr('src'));
	$('#'+id).bind({
		popupbeforeposition: function (event) {
			$('.filltext').textfill({maxFontPixels: 100, noWrap: true});
		},
		popupafterclose: function(event, ui) {
			$(window).off('orientationchange');
		}
	}).popup('open', {
		positionTo: 'window',
		history: false
	});
	return false;
}

function showErrorPopup(msg, debug) {
	logging.log('error', 'ERROR OCCURED: '+msg, 'error');
	if (debug) {
		logging.log('error', 'ERROR DESCRIPTION: '+debug, 'error');
	}
	setTimeout(function () {
		logging.send();
	}, 1000);
	if (typeof navigator != 'undefined' && typeof navigator.notification != 'undefined' && typeof navigator.notification.alert != 'undefined') {
		navigator.notification.alert(msg, null, 'Error Occurred');
	} else {
		alert(msg);
	}
}

function showUpdatePopup(callback) {
	navigator.notification.confirm('There are new version of app available. Do you want to download it?', function (buttonIndex) {
		if (buttonIndex == 2) {
			updater.check();
		}
		if (typeof(callback) == 'function') {
			callback(buttonIndex == 2);
		}
	}, 'Auto-updater', 'Cancel,Download');
}

function showFormError(page, data) {
	var error;
	$(page+'-error .error').detach();
	if (typeof data.errorText == 'undefined')
		error = data;
	else
		error = data.errorText;
	$(page+'-error').prepend('<div class="error">'+error+'</div>');
	$('.errorRow').removeClass('errorRow');
	if (typeof data.label != 'undefined' && data.label != '') {
		var row = $('.labelTxt:contains("'+data.label+'")').closest('.formRow');
		row.addClass('errorRow');
		$.scrollTo(row, 0);
	}
}

function confirmDeleteAccount(url){
	$('a[rel=delete]').off('click').on('click', function(){
		mv.postForm(url, {'delete': 'true'}, 'json', function(content, textStatus, xhr){
			if (content.redirect) {
				if (typeof(cacheStorage) != 'undefined') {
					cleanCache($('#back-link').attr('href'), function () {
						cleanCache('/mobile/account/dashboard');
						$('#back-link').trigger('click');
					});
				} else {
					$('#back-link').trigger('click');
				}
			}
		});
	});
	$('#delete-account').popup('open', {
		positionTo: 'window',
		history: false
	});
}

function showConnectionPopup(settings) {
	var lastPage = $.mobile.activePage;
	var dialog = $('#connect-dialog');
	$('#connect-button').off('click').on('click', function(evt){
		cancelDialog(dialog, lastPage);
		settings['real_connection'] = true;
		resendRequest(settings);
	});
	$('#noconnect-button').off('click').on('click', function(evt){
		logging.log('ajax', 'staying offline', 'info');
		dialog.dialog('close');
	});
	logging.log('design', 'showing connect dialog: ' + dialog.length, 'info');
	$.mobile.changePage(dialog);
	setTimeout(function () {
		$.mobile.loading('hide');
	}, 0);
}

//function barcodeCover(barcodeSource, barcodeSource2x) {
//	alert($('#details-page').length);
//	$('#details-page').off('pageshow').on('pageshow', function(){
//		alert('barcodeCover start');
//		$('img[alt="barcode"]').each(function(index, elem){
//			elem = $(elem);
//			if (elem.attr('src').length == 0) {
//				if (typeof(window.devicePixelRatio) != 'undefined' && window.devicePixelRatio > 1) {
//					elem.attr('src', barcodeSource2x);
//				} else {
//					elem.attr('src', barcodeSource);
//				}
//			}
//		});
//	});
//}

function travelplanCover(id, image) {
	if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
		cacheStorage.getItem(id.substring(1), function (data) {
			$(id).css('background-image', 'url('+(image).replace(/&amp;/g, '&')+')');
		}, function () {
			if (isOnline() || image.match(/^data:image/)) {
				$(id).css('background-image', 'url('+(image).replace(/&amp;/g, '&')+')');
			}
		});
		return;
	}
	if (isOnline() || image.match(/^data:image/)) {
		$(id).css('background-image', 'url('+(image).replace(/&amp;/g, '&')+')');
	}
}

function rBalance() {
	if (!$('.td-expire:visible:first').is(':visible'))
		return false;
	var n = $('.td-balance:visible:last');
	var l = n.find('.balance').text();
	n.find('.balance').text('-');
	var need = n.width();
	n.find('.balance').text(l);
	$('.td-expire:visible').each(function(index) {
		var bc = $(this).next();
		var b = bc.find('.balance');
        var c = parseInt(b.css('font-size'));
        var origin = b.data('original-font-size');
		if (bc.width() > need) {
            if (typeof(origin) == 'undefined')
                b.data('original-font-size', c);
			do {
				c -= 1;
				b.css('font-size', c);
			} while (bc.width() > need && c > 3);
		} else if (typeof(origin) != 'undefined') {
            while (c < origin) {
                c += 1;
                b.css('font-size', c);
                if (bc.width() == need)
                    continue;
                else {
                    b.css('font-size', c-1);
                    break;
                }
            }
        }
	});
	return true;
}

function detectSegments() {
	$('ul#list-tripSegments > li').each(function () {
		var ts = Math.round((new Date()).getTime() / 1000);
		var indent = 60 * 30;
		var startDateTime = parseInt($(this).attr('data-start-date-timestamp'));
		var endDateTime = parseInt($(this).attr('data-end-date-timestamp'));
		var c = 'future';

		if (ts >= (endDateTime + indent)) {
			c = 'past';
		} else if (ts >= startDateTime) {
            // do not mark comments as present
            if(!$(this).attr('data-comment'))
			    c = 'present';
		}
		$(this).addClass(c + "-trip");
	});
}

function fitConfNumber(){
	var elem = $(document).find('div.prop.noborder:first');
	var number = elem.find('.big.propVal');
	var max = elem.width() - elem.find('#confNumberLabel').width();
	if(number.width() + 10 > max){
		var fontsize = parseInt(number.css('font-size'));
		var m = parseInt(number.css('margin-top'));
		do{
			fontsize -= 1;
			m += 0.7;
			number.css('font-size', fontsize);
			number.css('margin-top', m);
		}while(number.width() > max)
	}
}
function hideDots() {
	var max = $('.segmentsDetails').width();
	var control = $('.controls');
	var dots = control.find('ul li');
	var all = control.find('ul li:not([class="active"])').hide();
	if (all.length == 0) return;
	var currentLeft, currentRigth;
	while(true) {
		//left
		currentLeft = dots.filter(':visible:first').prev();
		if (currentLeft.length == 1) {
			currentLeft.show();
			if (control.width() > max) {
				currentLeft.hide();
				break;
			}
		}
		//rigth
		currentRigth = dots.filter(':visible:last').next();
		if (currentRigth.length == 1) {
			currentRigth.show();
			if (control.width() > max) {
				currentRigth.hide();
				break;
			}
		}
		if (currentLeft.length == 0 && currentRigth.length == 0)
			break;
	}
}

function displayRoute(directionsId, map, start, end, unknownError) {
	if (unknownError === undefined)
		unknownError = false;
	map.displayDirections({
		'origin':start,
		'destination':end,
		'travelMode':google.maps.DirectionsTravelMode.DRIVING
	}, { 'panel':document.getElementById(directionsId)}, function (response, status) {

		if (status != google.maps.DirectionsStatus.OK) {
			if (!unknownError)
				displayRoute(map, fromName, toName, true);
			else {
				document.getElementById(directionsId).innerHTML = "Could not calculate driving directions";
			}
		}
	});
}

var customSearchDelayHandle = 0;
$( document ).delegate( ":jqmData(role='listview')", "listviewcreate", function() {

	var list = $( this ),
		listview = list.data( "listview" );

	if ( !list.data('delay-filter') ) {
		return;
	}

	var wrapper = $( "<form>", {
			"class": "ui-listview-filter ui-bar-" + listview.options.filterTheme,
			"role": "search"
		}),
		search = $( "<input>", {
			placeholder: listview.options.filterPlaceholder
		})
			.attr( "data-" + $.mobile.ns + "type", "search" )
			.jqmData( "lastval", "" )
			.bind( "keyup change", function() {
				if (customSearchDelayHandle != 0) {
					clearTimeout(customSearchDelayHandle);
				}
				customSearchDelayHandle = setTimeout($.proxy(function () {
					var $this = $( this ),
						val = this.value.toLowerCase(),
						listItems = null,
						lastval = $this.jqmData( "lastval" ) + "",
						childItems = false,
						itemtext = "",
						item,
					// Check if a custom filter callback applies
						isCustomFilterCallback = listview.options.filterCallback !== defaultFilterCallback;

					logging.log('design', 'perform search for: '+val, 'debug');

					listview._trigger( "beforefilter", "beforefilter", { input: this } );

					// Change val as lastval for next execution
					$this.jqmData( "lastval" , val );
					if ( isCustomFilterCallback || val.length < lastval.length || val.indexOf( lastval ) !== 0 ) {

						// Custom filter callback applies or removed chars or pasted something totally different, check all items
						listItems = list.children();
					} else {

						// Only chars added, not removed, only use visible subset
						listItems = list.children( ":not(.ui-screen-hidden)" );
					}

					if ( val ) {

						// This handles hiding regular rows without the text we search for
						// and any list dividers without regular rows shown under it

						for ( var i = listItems.length - 1; i >= 0; i-- ) {
							item = $( listItems[ i ] );
							itemtext = item.jqmData( "filtertext" ) || item.text();

							if ( item.is( "li:jqmData(role=list-divider)" ) ) {

								item.toggleClass( "ui-filter-hidequeue" , !childItems );

								// New bucket!
								childItems = false;

							} else if ( item.is( "li:jqmData(role=list-header-divider)" ) ) {

								item.toggleClass( "ui-filter-hidequeue" , !childItems );

							} else if ( listview.options.filterCallback( itemtext, val, item ) ) {

								//mark to be hidden
								item.toggleClass( "ui-filter-hidequeue" , true );
							} else {

								// There's a shown item in the bucket
								childItems = true;
							}
						}

						// Show items, not marked to be hidden
						listItems
							.filter( ":not(.ui-filter-hidequeue)" )
							.toggleClass( "ui-screen-hidden", false );

						// Hide items, marked to be hidden
						listItems
							.filter( ".ui-filter-hidequeue" )
							.toggleClass( "ui-screen-hidden", true )
							.toggleClass( "ui-filter-hidequeue", false );

					} else {

						//filtervalue is empty => show all
						listItems.toggleClass( "ui-screen-hidden", false );
					}
					listview._refreshCorners();

				}, this), 500);
			})
			.appendTo( wrapper )
			.textinput();

	if ( listview.options.inset ) {
		wrapper.addClass( "ui-listview-filter-inset" );
	}

	wrapper.bind( "submit", function() {
		return false;
	})
		.insertBefore( list );
});
