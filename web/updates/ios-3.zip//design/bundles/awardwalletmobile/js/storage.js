var cacheStorage = function () {
	var self = {};

	self.rootDir = null;

	self.encodeFilename = function(key){
		return encodeURIComponent(key).replace(/%/ig, '_');
	};

	self.decodeFilename = function(key){
		return decodeURIComponent(key.replace(/_/ig, '%'));
	};

	self.getItem = function (key, callback, nofile) {
		var filename = self.encodeFilename(key);
		logging.log('cacheStorage', 'get: ' + key, 'debug');
		self.rootDir.getFile(filename, {create: false}, function (file) {
			var reader = new FileReader();
			reader.onloadend = function(evt) {
				if (typeof(callback) == 'function')
					logging.log('cacheStorage', 'got file: ' + key, 'debug');
					callback(evt.target.result);
			};
			reader.readAsText(file);
		}, function (error) {
			logging.log('cacheStorage', 'Unable to read file: ' + error.code, 'debug');
			if (typeof(nofile) == 'function')
				nofile(key);
		});
	};

	self.setItem = function (key, value, callback) {
		var filename = self.encodeFilename(key);
		logging.log('cacheStorage', 'writing: ' + key + ' into ' + filename, 'debug');
		self.rootDir.getFile(filename, {create: true, exclusive: false}, function (file) {
			file.createWriter(function (writer) {
				writer.onwriteend = function(evt){
					logging.log('cacheStorage', 'Write value to file complete: '+key, 'debug');
					if (typeof(callback) == 'function')
						callback(true);
				};
				writer.write(value);
			},
			function (error) {
				logging.log('cacheStorage', 'Unable to write file ' + key
				+ ' to ' + self.rootDir.fullPath + ': ' + JSON.stringify(error)
				+ ' data: ' + JSON.stringify(value), 'error');
				if (typeof(callback) == 'function')
					callback(false);
			});
		}, function (error) {
			logging.log('cacheStorage', 'Unable to create file: ' + error.code, 'error');
			if (typeof(callback) == 'function')
				callback(false);
		});
	};

	self.removeItem = function (key, callback) {
		var filename = self.encodeFilename(key);
		self.rootDir.getFile(filename, {create: false}, function (file) {
			file.remove(function () {
				// success
				if (typeof(callback) == 'function')
					callback(true);
			}, function (error) {
				logging.log('cacheStorage', 'Error removing file: ' + error.code, 'error');
				if (typeof(callback) == 'function')
					callback(false);
			});
		}, function (error) {
			logging.log('cacheStorage', 'Unable to find file: ' + error.code, 'debug');
			if (typeof(callback) == 'function')
				callback(false);
		});
	};

	self.clear = function () {
		self.rootDir.createReader().readEntries(function (entries) {
			for (var i = 0; i < entries.length; i++) {
				if (entries[i].isFile && entries[i].name.indexOf('_2F') == 0) {
					entries[i].remove(function () {
						// success
					}, function (error) {
						logging.log('cacheStorage', 'Error removing file ' + entries[i].name + ' : ' + error.code, 'error');
					});
				}
			}
		}, function (error) {
			logging.log('cacheStorage', "Failed to list directory contents: " + error.code, 'error');
		});
	};

	self.clearExcluded = function (list) {
		self.rootDir.createReader().readEntries(function (entries) {
			var rm = [];
			var i;
			for (i = 0; i < entries.length; i++) {
				if (entries[i].isFile && entries[i].name.indexOf('_2F') == 0) {
					var key = entries[i].name;
					getCache(key, function (cache) {
						if (cache.valid) {
							if (!list.hasOwnProperty(self.decodeFilename(cache.key))) {
								self.removeItem(cache.key);
							}
						}
					});
				}
			}
		}, function (error) {
			logging.log('cacheStorage', "Failed to list directory contents: " + error.code, 'error');
		});
	};

	self.init = function () {
		logging.log('cacheStorage', 'init', 'debug');
		window.requestFileSystem(LocalFileSystem.TEMPORARY, 0, function (fileSystem) {
			logging.log('cacheStorage', 'got temp dir', 'debug');
			var dir;
			if(config.device == 'ios')
				dir = '/../Library/Caches/com.awardwallet.iphone/cache';
			else
				dir = 'prefetch';
			logging.log('cacheStorage', 'requesting dir: '+dir, 'debug');
			fileSystem.root.getDirectory(dir, {create: true}, function (dir) {
				self.rootDir = dir;
				logging.log('cacheStorage', 'get cache dir: '+dir.fullPath);
//				self.setItem('self/test', 'hello', function(result){
//					logging.log('cacheStorage', 'self test: ' + JSON.stringify(result));
//				});
			}, function (error) {
				logging.log('cacheStorage', 'Unable to create new directory: ' + error.code, 'error');
			});
		}, function (evt) {
			logging.log('cacheStorage', 'Can not get fs: '+evt.target.error.code, 'error');
		});
	};

	return self;
}();
