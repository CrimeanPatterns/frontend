var os = getOs();
if (typeof config == 'undefined')
    var config = {'netMode': 0, 'baseHost':''};

function getOs(){
    var ua = navigator.userAgent;
    if(ua.match("Linux; U; Android"))
        return 'android';
    return null;
}
function isAppleBrowser() {
	return (
		(navigator.userAgent.toLowerCase().indexOf("ipad") > -1) ||
		(navigator.userAgent.toLowerCase().indexOf("iphone") > -1) ||
		(navigator.userAgent.toLowerCase().indexOf("ipod") > -1)
	);
}

function reloadPage(nocheck) {
	if (typeof device != 'undefined') {
		if (!isOnline() && !nocheck) {
			$.ajax({
				url: config.baseHost + '/mobile/login_status',
				cache: false,
				silent: false, // should get connection dialog todo: refactor that
				success: function () {
					reloadPage(true);
				}
			});
			return;
		}
		if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
			$.mobile.loading('show');
			antiPrefetch.load(true);
			return;
		}
		var url = cacheKey(document.URL);
		logging.log('design', 'reload page: '+url, 'info');
		if (typeof(prefetch.LinksList[url]) == 'undefined') {
			$.mobile.changePage(url, {
				allowSamePageTransition: true,
				reloadPage: true
			});
		} else {
			$.mobile.loading('show');
		}
		if (typeof(prefetch) != 'undefined')
			prefetch.reload(true);
	} else {
		document.location.reload();
	}
}

function mobileView() {
	this.isset = function(v) {
		return typeof v != 'undefined';
	};
	this.postForm = function(url, data, dataType, success, fail, loadMessage, timeout) {
		if (typeof dataType == 'undefined')
			dataType = 'html';
		if (typeof loadMessage == 'undefined')
			loadMessage = true;
		if (typeof timeout == 'undefined')
			timeout = 30000;
		if (loadMessage)
			$.mobile.loading('show');
		return $.ajax({
			url: url,
			useCache: false,
			dataType: dataType,
			cache: false,
			type: 'POST',
			data: data,
			timeout: timeout,
			success: function(content, textStatus, xhr){
				if (loadMessage)
					$.mobile.loading('hide');
				success(content, textStatus, xhr);
			},
			error: function(jqXHR, textStatus, errorThrown){
				$.mobile.loading('hide');
				logging.log('postForm', jqXHR, 'error');
				logging.log('postForm', textStatus, 'error');
				logging.log('postForm', errorThrown, 'error');
				if (typeof(fail) == 'function')
					fail(jqXHR, textStatus, errorThrown);
			}
		});
	};
}

// Listen for any attempts to call changePage().
function handleExternalUrls( e, data ) {
	// We only want to handle changePage() calls where the caller is
	// asking us to load a page by URL.
	if ( typeof data.toPage === "string" ) {
		if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
			var cache = $('#list-page.persistent');
			if (data.toPage.endsWith('/mobile/account/list/all') && cache.length) {
				e.preventDefault();
				console.log('DOM cache hit: account-list');
				$.mobile.changePage(cache);
				return;
			}
		}

		logging.log('ajax', 'handleExternalUrls: '+data.toPage, 'info');

		var u = $.mobile.path.parseUrl( data.toPage );
		// jqm adds "top: 232px" to div.ui-loader after keyboard show/hide, so we will reset it to top
		$('div.ui-loader').css('top', '0px');
		setTimeout(function () {
			$.mobile.loading('show');
		}, 0);
		var url = u.pathname;
		url = data.toPage;
		$.ajax({
			url: url,
			headers: {'Partial-Page': 'true'},
			storeCache: false, // do not use cache for bad response, we will check response first
			success: function(response, textStatus, jqXHR){
				// check html version
				if (typeof(response) == 'string' && typeof textStatus != 'undefined' &&  typeof jqXHR != 'undefined') {
					var matches = response.match(/<!-- htmlversion=(\d+) -->/);
					if (matches && matches.length == 2) {
						var version = matches[1];
	                    if (version != config.htmlVersion) {
							showUpdatePopup(function (updating) {
								if (!updating && !updater.updateInProgress) {
									getCache(document.URL, function (cache) {
										if (cache.valid) {
											$.mobile.changePage(document.URL, {
												allowSamePageTransition: true,
												reloadPage: true
											});
										}
										$.mobile.loading('hide');
									});
								}
							});
							return;
						}
					}
				}
				var content = $('<div/>');
				if (typeof(response) == 'string' && response.indexOf('data-role') > 0) {
					content.html(response);
					if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
						$('#list-page', content).addClass('persistent');
					}
					var page = content.children("div[data-role=page], div[data-role=dialog]");
					if(page.length > 0){
						var oldPages = $('body').children('div[data-role=page], div[data-role=dialog]').not('.persistent');
						if(oldPages.length > 1){
							var toRemove = oldPages.not(':last');
							toRemove.detach();
						}
						page.appendTo($('body')).page();
						data.options.dataUrl = url;
						$.mobile.changePage(page, data.options);
						if (response.indexOf('<!-- phonegap:nocache -->') == -1 && typeof textStatus != 'undefined' &&  typeof jqXHR != 'undefined') {
							logging.log('ajax', 'try set cache from handleExternalUrls', 'debug');
							trySetCache({
								type: 'GET',
								url: url
							}, response);
						}
					}
					else{
						showErrorPopup('There has been an connection error on this page. Please try again later.', 'empty page');
					}
				}
				else
					showErrorPopup('There has been an network error on this page. Please try again later.', 'no page');
				setTimeout(function () {
					$.mobile.loading('hide');
				}, 0);
			}
		});
		e.preventDefault();
	}
}

var fetchNextFromCache = false;

function ajaxBeforeSendHandler(request, settings){
	fetchNextFromCache = false;

	if ((typeof(settings.cacheFail) == 'boolean' && settings.cacheFail == true) || (typeof(settings.useCache) == 'boolean' && !settings.useCache)) {

		if (!isOnline() && !settings.silent && !settings.real_connection) {
			showConnectionPopup(settings);
			return false;
		}

		// make a real request
		if(typeof(localStorage['PHPSESSID']) == 'string'){
			request.setRequestHeader('x-phpsessid', localStorage['PHPSESSID']);
		}
		if(typeof(localStorage['PwdHash']) == 'string'){
			request.setRequestHeader('x-pwdhash', localStorage['PwdHash']);
		}
		request.setRequestHeader('x-phonegap', '1');

		logging.log('ajax', settings.type + ' ' + settings.url, 'info');

		settings.url = settings.url.replace('file://', '');

		if((settings.url.endsWith('mobile/login') || settings.url.endsWith('mobile/login.html')) && $('#login-page').length) {
			logging.log('ajax', 'changing page to login page', 'info');
			$.mobile.changePage($('#login-page'));
			setTimeout(function () {
				$.mobile.loading('hide');
			}, 0);
			return false;
		}
		if(settings.url.indexOf('http://') == -1 && settings.url.indexOf('https://') == -1){
			// relative path, connect to host
			settings.url = config.baseHost + settings.url;
		} else{
			// replace host to prevent url open in webview
			settings.url = settings.url.replace(/http(s)?:\/\/[^\/]awardwallet[^\/]+/i, config.baseHost);
		}
		settings.url = settings.url.replace("app_dev.php/app_dev.php", "app_dev.php");

		logging.log('ajax', 'actual url: ' + settings.url, 'info');

		if (typeof(settings.xhrpool) == 'undefined' || settings.xhrpool != 'prefetch')
			$.xhrPool.abort('prefetch');

		return true;
	} else {
		setTimeout(function () {
			if (typeof(config.antiPrefetchEnabled) != 'undefined' && config.antiPrefetchEnabled) {
				setTimeout(function () {
					var content = antiPrefetch.render(cacheKey(settings.url));
					if (content) {
						console.log('PROXING');
						settings.success(content);
					} else {
						settings['cacheFail'] = true;
						$.ajax(settings);
					}
				}, 0);
			} else
			getCache(settings.url, function (cache) {
				if(isOnline() && cache.valid && settings.type == 'GET'){
					if (!isCacheExpired(cache)){
						logging.log('ajax', 'load from cache instead live', 'info');
						if (config.netMode == 2) {
							logging.log('ajax', 'disabled by config.netMode - load from live', 'warning');
						} else {
							if (typeof(prefetch) != 'undefined')
								prefetch.check(cacheKey(settings.url));
							settings.success(cache.content);
							return;
						}
					}
				}

				if(!isOnline() || (fetchNextFromCache && cache.valid)){
					if(cache.valid && settings.type == 'GET'){
						logging.log('ajax', 'returning cached response', 'info');
						settings.success(cache.content);
						return;
					} else {
						showConnectionPopup(settings);
						return;
					}
				}

				// run real request
				settings['cacheFail'] = true;
				$.ajax(settings);
			});
		}, 0);
	}

	return false;
}

function resendRequest(settings){
	logging.log('ajax', 'resending request', 'info');
	$.mobile.loading('show');
	//switchOnline();
	$.ajax(settings);
}

function ajaxSuccessHandler(evt, request, settings){
	logging.log('ajax', "request complete: " + settings.url, 'info');
	logging.log('ajax', 'try set cache from ajaxSuccessHandler', 'debug');
	trySetCache(settings, request.responseText);
}

function ajaxErrorHandler(evt, request, settings){
	$.mobile.loading('hide');
	if (settings.silent) {
		logging.log('ajax', "request failed silent: " + settings.url + ', status: ' + request.status + ', ' + request.statusText, 'warning');
		return;
	}
	if (('abort' === request.statusText || request.readyState == 0) && settings.real_connection) {
		showErrorPopup('There is no internet connection available.', 'connection aborted');
		history.back();
		return;
	}
	if ("abort" != request.statusText)
		logging.log('ajax', "request failed: " + settings.url + ', status: ' + request.status + ', ' + request.statusText, 'error');
	if (403 === request.status) {
		// not authorized, possible session timed out
		// now we will re-authorize using rememberMe cookie
		if (typeof(prefetch) != 'undefined')
			prefetch.stop();
		localStorage.clear();
		cacheStorage.clear();
		logging.log('ajax', 'Error 403 => Logout', 'error');
		logging.log('ajax', 'loginPageLocation: ' + config.loginPageLocation);
		document.location.href = config.loginPageLocation;
		return;
  	}
	if (500 === request.status) {
		showErrorPopup('There has been an error on this page. This error was recorded and will be fixed as soon as possible.', 'http 500');
		return;
  	}
	if('abort' === request.statusText){
		return;
	}
	if (expectedError) {
		expectedError = false;
		showErrorPopup('Internet connection lost. Please, try again.', 'online, but connection type changed');
	} else {
		logging.log('ajax', "request failed: " + JSON.stringify(request), 'error');
		logging.log('ajax', "request failed settings: " + JSON.stringify(settings), 'error');
		showErrorPopup('There has been an error on this page.', 'unknown ajax request error, status: ' + request.status + ', ' + request.statusText);
	}
	logging.log('ajax', "request failed: " + settings.url + ', status: ' + request.status + ', ' + request.statusText, 'error');
}

function changePage(link, options) {
	$.mobile.changePage(link, options);
}

function isCurrentPage(url) {
	//if (url.indexOf('dashboard') > -1)
	//	return false;
	return document.URL.endsWith(url);
}

$(document).on("mobileinit", function createSimpleHandler() {
	var simpleHandler = function( name, reverse, $to_p, $from_p ) {

		var deferred = new $.Deferred(),
			none = !$.support.cssTransitions || !name || name === "none",
			$to = $to_p,
			$from = $from_p,

			toggleViewportClass = function() {
				$.mobile.pageContainer.toggleClass( "ui-mobile-viewport-transitioning viewport-" + name );
			},

			done = function() {
				if ( $from ) {
					$from
						.height( "" )
						.removeClass( $.mobile.activePageClass + " out in reverse " + name );
				}
				$to
					.height( "" )
					.removeClass( "out in reverse " + name );
				toggleViewportClass();
				deferred.resolve( name, reverse, $to, $from, true );
			};

		$to.addClass( $.mobile.activePageClass );
		// Note: In many applications the following line may be unnecessary, and may be removed
		$.mobile.focusPage( $to );  // Send focus to page as it is now display: block
		if (none) {
			if ( $from ) {
				$from.removeClass( $.mobile.activePageClass );
			}
			deferred.resolve( name, reverse, $to, $from, true );
		} else {
			var screenHeight = $.mobile.getScreenHeight(),
				reverseClass = reverse ? " reverse" : "";
			toggleViewportClass();
			$to.animationComplete( done );
			$to
				.height( screenHeight ) // Note: setting an explicit height helps eliminate tiling in the transitions
				.addClass( name + " in" + reverseClass );
			$from
				.height( screenHeight )
				.addClass( name + " out" + reverseClass );
		}
		return deferred.promise();
	};
	$.mobile.transitionHandlers.simple = simpleHandler;
});

(function($) {
	$.fn.textfill = function(options) {
		var fontSize = options.maxFontPixels;
		var noWrap = options.noWrap;
		var ourText = $('span:visible:first', this);
		if (noWrap) {
			ourText.css('white-space', 'nowrap');
		}
		var maxWidth = $(this).width();
		var textHeight;
		var textWidth;
		do {
			ourText.css('font-size', fontSize);
			textHeight = ourText.height();
			textWidth = ourText.width();
			fontSize = fontSize - 1;
		} while ((textWidth > maxWidth) && fontSize > 3);
		return this;
	}
})(jQuery);

(function($) {
	$.xhrPool = {};

	$.xhrPool.abortAll = function() {
		$.each(this, function(pool, map) {
			$.each(map, function(idx, jqXHR) {
				jqXHR.abort();
				$.xhrPool[pool].splice(idx, 1);
			});
		});
	};

	$.xhrPool.abort = function(pool) {
		if (typeof this[pool] != "undefined") {
			$.each(this[pool], function(idx, jqXHR) {
				try {jqXHR.abort();} catch (e) {}
				$.xhrPool[pool].splice(idx, 1);
			});
		}
	};

	$.ajaxPrefilter(function(options, originalOptions, jqXHR) {
		var pool = options.xhrpool || "global";

		if ( ! $.xhrPool[pool]) {
			$.xhrPool[pool] = [];
		}

		$.xhrPool[pool].push(jqXHR);
	});
})(jQuery);

function askAboutApp() {
    if (isAppleBrowser() && getCookie('isAskedAboutApp') != '1') {
        var expDate = new Date();
        if (window.confirm('Do you want to install Awardwallet app?')) {/*review*/
            expDate.setTime(expDate.getTime() + 30 * 24 * 3600 * 1000); // 30 days
            setCookie('isAskedAboutApp', '1', expDate, '/');
            window.location = "http://itunes.apple.com/us/app/awardwallet/id388442727?mt=8";
        } else {
            expDate.setTime(expDate.getTime() + 3 * 24 * 3600 * 1000); // 3 days
            setCookie('isAskedAboutApp', '1', expDate, '/');
        }
    }
}

function bodyLoaded(){
	console.log('bodyLoaded');
	document.addEventListener("deviceready", function () {
		console.log('deviceReady');
		setTimeout(function () {
			console.log('deviceReady timer');
			$('#appVersion').text(config.appVersion);
			config.loginPageLocation = document.location.href;
			mobileInit();
			initPage();
			if (typeof(updater) != 'undefined')
				updater.init();
		}, 500);
	}, false);
}