function getCache(url, callback){
	var key = cacheKey(url);
	if (typeof(cacheStorage) != 'undefined')
	cacheStorage.getItem(key, function (cached) {
		var result = {};
		result.valid = typeof(cached) == 'string';
		if(result.valid){
			cached = jQuery.parseJSON(cached);
			if (!jQuery.isPlainObject(cached)) {
				if (typeof(callback) == 'function')
					callback(result);
				return;
			}
			cached.content = cached.content || '';
			cached.lastUpdate = cached.lastUpdate || 0;
			cached.checksum = cached.checksum || 0;
			logging.log('cache', 'exists, date: ' + cached.lastUpdate + ', content.length: ' + cached.content.length + ', content.checksum: ' + cached.checksum, 'debug');
			result.key = key;
			result.content = cached.content;
			result.lastUpdate = cached.lastUpdate;
			result.checksum = cached.checksum;
		}
		if (typeof(callback) == 'function')
			callback(result);
	}, function (key) {
		var result = {};
		result.key = key;
		result.valid = false;
		if (typeof(callback) == 'function')
			callback(result);
	});
}

var cacheFakeNow = 0;
function isCacheExpired(cache) {
	var cacheExpire = new Date(cache.lastUpdate).getTime() + 1000 * 3600;
	return (Math.max(cacheFakeNow, Date.now()) > cacheExpire);
}

/*
 * setting: type, url
 */
function trySetCache(settings, data) {
	if(settings.type == 'GET'
		&& (typeof(settings.useCache) == 'undefined' || settings.useCache)
		&& (typeof(settings.storeCache) == 'undefined' || settings.storeCache)
		&& (settings.url.indexOf('dashboard') > 0 || typeof(prefetch.LinksList[cacheKey(settings.url)]) != 'undefined'))
	{
		setCache(settings.url, data);
	}
}

function setCache(url, data, checksum, date, refresh, callback) {
	var key = cacheKey(url);
	date = date || false;
	getCache(key, function (cache) {
		replaceImage(data, function (data, withimage) {
			if (withimage && typeof(prefetch.LinksList[key]) != 'undefined') {
				prefetch.LinksList[key].check = false;
				logging.log('cache', 'prefetch content check disabled for: '+key, 'debug');
			}
			if (typeof(cacheStorage) != 'undefined')
			cacheStorage.setItem(key, JSON.stringify({
				content: data,
				lastUpdate: date ? date : new Date(),
				checksum: checksum || 0
			}), function () {
				logging.log('cache', 'set cache: '+key+', '+date, 'debug');
				if (typeof(callback) == 'function')
					callback(true);
				var changed = cache.valid ? cache.content != data : true;
				if (isCurrentPage(key) && refresh && changed) {
					$.mobile.changePage(key, {
						allowSamePageTransition: true,
						reloadPage: true
					});
					logging.log('cache', 'page refreshed - '+key, 'warning');
				}
			});
		});
	});
}

function cacheKey(url){
	var u = $.mobile.path.parseUrl(url);
	var key = u.pathname;
	key = key.replace('app_dev.php/', '');
	return key;
}

function cleanCache(url, callback){
	logging.log('cache', 'clean: ' + url, 'info');
	var key = cacheKey(url);
	if (typeof(cacheStorage) != 'undefined')
		getCache(key, function (cache) {
			if (cache.valid) {
				cache.lastUpdate = new Date(Date.now() - 1000 * (3600 + 1));
				cache.checksum = 0; // prevent refresh
				setCache(key, cache.content, cache.checksum, cache.lastUpdate, false, callback);
			} else {
				if (typeof(cacheStorage) != 'undefined')
					cacheStorage.removeItem(key, callback);
			}
		});
	else
		if (typeof(callback) == 'function')
			callback();
	return url;
}

function invalidateCache() {
	logging.log('cache', 'invalidating', 'info');
	cacheFakeNow = Date.now() + 1000 * 3600 + 1;
}

function clearCache() {
	logging.log('cache', 'cache clearing', 'info');
	if (typeof(cacheStorage) != 'undefined')
		cacheStorage.clear();
}

function encodeImage(url, callback, param) {
	var canvas = document.createElement('canvas');
	var ctx = canvas.getContext('2d');
	var img = new Image();
	img.onload = function () {
		canvas.width  = img.width;
		canvas.height = img.height;
		ctx.drawImage(img, 0, 0, img.width, img.height);
		logging.log('cache', 'image loaded', 'debug');
		if (typeof(callback) == 'function')
			callback(canvas.toDataURL(), true, param);
	};
	img.onerror = function () {
		logging.log('cache', 'image not loaded', 'debug');
		if (typeof(callback) == 'function')
			callback(url, false, param);
	};
	img.src = url;
}

function replaceImage(text, callback) {
	var matches = text.match(/travelplanCover\('#ava\d+', '([^']+)'\)/);
	if (isOnline() && matches && typeof(matches[1]) == 'string')	{
		var url = matches[1];
		logging.log('cache', 'find a url to replace: '+url, 'debug');
		encodeImage(url, function (data, withimage) {
			logging.log('cache', 'image replace', 'debug');
			if (typeof(callback) == 'function')
				callback(text.split(url).join(data),  withimage);
		});
	} else {
		if (typeof(callback) == 'function')
			callback(text, false);
	}
}
