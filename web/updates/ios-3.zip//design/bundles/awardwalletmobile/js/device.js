function isApple() {
	if (typeof device != 'undefined') {
		if (device.platform.indexOf('iPhone') > -1 ||
			device.platform.indexOf('iPad') > -1 ||
			device.platform.indexOf('iOS') > -1)
		{
			return true;
		}
	}
	return false;
}

var lastConnectionType = null;
var expectedError = false;

$(document).ready( function () {
	document.addEventListener('deviceready', function(){
		setTimeout(function () {
			logging.log('device', 'hiding splashscreen from 5sec timeout', 'info');
			hideSplashscreen();
		}, 5000);
		lastConnectionType = Connection.UNKNOWN;
		$(document).on("online", function () {
			onlineState = true;
			expectedError = false;
			progressBar.state(onlineState);
			if (lastConnectionType != navigator.connection.type) {
				expectedError = true;
			}
			lastConnectionType = navigator.connection.type;
			logging.log('device', 'Go online! Connection type: '+navigator.connection.type, 'info');
			prefetch.wait('internal', true);
		});
		$(document).on("offline", function () {
			onlineState = false;
			expectedError = false;
			progressBar.state(onlineState);
			logging.log('device', 'Go offline! Connection type: '+navigator.connection.type, 'info');
		});

	}, false);
});

function hideSplashscreen() {
	if (typeof navigator != 'undefined' && typeof navigator.splashscreen != 'undefined') {
		logging.log('device', 'hide splashscreen', 'debug');
		navigator.splashscreen.hide();
	}
}

function filePath(url){
	if(onDevice())
		return url + '.html';
	else
		return url;
}

function onDevice(){
	return document.location.protocol == 'file:';
}

function switchOnline(){
	if(config.netMode > 0)
		config.netMode = 0;
	else
		config.netMode = 1;
}

var onlineState = true;
function isOnline(){
	if (typeof device != 'undefined') {
		if (navigator.connection.type == Connection.UNKNOWN) {
			return (config.netMode > 0) && onlineState;
		} else {
			return (config.netMode > 0) && (navigator.connection.type != Connection.NONE);
		}
	}
	return true;
}

function handleOpenURL(url) {
	logging.log('device', 'handleOpenURL: '+url, 'info');
	setTimeout(function() {
		var path = url.match(/awardwallet:\/\/(.*)/)[1];
		if (!isCurrentPage(path)) {
			logging.log('device', 'should redirect to: '+path, 'warning');
			$.mobile.changePage(path);
		}
	}, 0);
}

function showAdvertisment(show) {
	if (typeof window.plugins == 'undefined' || typeof window.plugins.iAdPlugin == 'undefined') {
	    return;
	}

	var $window = $(window);

	$window.off("orientationchange");
	$window.off("iAdBannerViewDidLoadAdEvent");
	$window.off("iAdBannerViewDidFailToReceiveAdWithErrorEvent");

	if (show) {
		$window.on("orientationchange", window.plugins.iAdPlugin.orientationChanged);

		$window.on("iAdBannerViewDidLoadAdEvent", function (evt) {
			console.log("banner loaded");
			window.plugins.iAdPlugin.showAd(true);
		});

		$window.on("iAdBannerViewDidFailToReceiveAdWithErrorEvent", function (evt) {
			console.log('no banner');
			window.plugins.iAdPlugin.showAd(false);
		});

		window.plugins.iAdPlugin.orientationChanged();

		console.log('prepare iad');
		window.plugins.iAdPlugin.prepare(true);
		console.log('show iad');
		window.plugins.iAdPlugin.showAd(true);
	} else {
		window.plugins.iAdPlugin.showAd(false);
	}

}

function openBrowser(url, params, data) {
	var step = 'start';
	window.plugins.childBrowser.onLocationChange = function (loc) {
		console.log('childBrowser.onLocationChange: '+loc);
		if (params && data && step) {
			var _setNextStep = 'setNextStep:function(name,callback){document.location="aw://nextstep?"+encodeURIComponent(name).replace(/\'/g, "%27");if(typeof(callback)=="function"){setTimeout(callback,0)}}';
			var _error = 'error:function(text){setTimeout(function(){document.location="aw://error?"+encodeURIComponent(text).replace(/\'/g, "%27")},0)}';
			var _complete = 'complete:function(){setTimeout(function(){document.location="aw://complete"},0)}';
			var _getDepDate = 'getDepDate:function(){return new Date((typeof(params.depDate)!="undefined"&&params.depDate)?params.depDate*1000:Date.now())}';

			var api = 'var api={'+_setNextStep+','+_error+','+_complete+','+_getDepDate+'};';
			var param = 'var params=' + JSON.stringify(params) + ';';
			var code = '(function($){' + api + param + data + ';plugin.' + step + '(params)})';

			var jquery = window.jQuerySource + ';' + code + '(jQuery.noConflict(true))';
			window.plugins.childBrowser.jsExec(jquery);
		}
	};
	window.plugins.childBrowser.onCommand = function (url) {
		console.log('childBrowser.onCommand: '+url);
		var parts = $.mobile.path.parseUrl(url);
		if (parts && parts.hostname == 'nextstep') {
			step = decodeURIComponent(decodeURIComponent(parts.search.substring(1)));
		}
		if (parts && parts.hostname == 'error') {
			alert(decodeURIComponent(decodeURIComponent(parts.search.substring(1))));
			step = '';
		}
		if (parts && parts.hostname == 'complete') {
			step = '';
		}
	};
	window.plugins.childBrowser.onClose = function () {
		console.log('childBrowser.onClose');
		$.mobile.loading('hide');
	};
	window.plugins.childBrowser.onOpenExternal = function () {
		console.log('childBrowser.onOpenExternal');
	};

	window.plugins.childBrowser.showWebPage(url);
}

function showFlightStatus(provider, flight) {
	$.mobile.loading('show');
	if (!window.jQuerySource) {
		$(document).ready(function(){
			$.ajax({
				url: '../lib/3dParty/jquery/jq.js',
				dataType: 'text',
				beforeSend: function () {},
				error: function () {},
				complete: function () {},
				success: function (data) { window.jQuerySource = data; }
			});
		});
	}
	$.ajax({
		url:config.baseHost + '/engine/'+provider+'/extensionMobile.js',
		dataType: 'text',
		cache: false,
		useCache: false,
		silent: true,
		success: function (data) {
			try {
				var api = {};
				var params = { flightNumber: flight };
				eval(data);
				if (typeof(plugin.match) != 'undefined') {
					if (!plugin.match.test(params.flightNumber)) {
						alert('Unsupported flight number!');
						return;
					}
				}
				openBrowser(plugin.url, params, data);
			} catch (e) {
				alert('Fail parse extensionMobile.js');
				$.mobile.loading('hide');
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){
			alert('Fail retrieve extensionMobile.js');
			logging.log('showFlightStatus', 'error in response: ' + textStatus + ', ' + errorThrown, 'error');
			$.mobile.loading('hide');
		}
	});
}
